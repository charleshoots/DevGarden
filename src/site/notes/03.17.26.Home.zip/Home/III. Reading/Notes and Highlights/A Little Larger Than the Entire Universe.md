---
{"title":"Notes from A Little Larger Than the Entire Universe","aliases":["Notes from A Little Larger Than the Entire Universe"],"created":"2026-03-16T18:10:07.961-10:00","updated":"2026-03-17T14:14:07.325-10:00","tags":["reading-notes-old","Reading","reading-note"],"dg-publish":true,"dg-note-icon":"stone","dg-path":"III. Reading/Notes and Highlights/A Little Larger Than the Entire Universe","permalink":"/iii/","dgPassFrontmatter":true,"noteIcon":"stone"}
---






# A Little Larger Than the Entire Universe
##### Fernando Pessoa

## Copyright Page
### Page 10 @ 28 June 2023 12:17:02 AM
<u>Back in Durban, Pessoa, at the age of fifteen or sixteen, invented Charles Robert Anon, his first alter ego to sign a substantial body of creative writing, including poems, short stories, and essays. This English proto-heteronym was soon joined by the even more prolific Alexander Search, either while Pessoa was still in Durban or else shortly after his definitive return to Lisbon, in the fall of 1905. Search, who likewise wrote in English but was supposedly born in Lisbon on the same day as Pessoa, expressed, like Anon, the intellectual concerns and existential anxieties of a young man on the threshold of becoming an adult. Pessoa, in a certain way, remained forever on that threshold. Instead of getting down to the practical business of living, he continued to wrestle with theoretical problems and the big questions: the existence of God, the meaning of life and the meaning of death, good vs. evil, reality vs. appearance, the idea (is it just an idea?) of love, the limits of consciousness, and so on. All of which was rich fodder for his poetry, thriving as it did on ideas more than on actual experience.</u>

## ALBERTO CAEIRO
### Page 29 @ 28 June 2023 01:30:04 AM
**I’m not a materialist or a deist or anything else. I’m a man who one day opened the window and discovered this crucial thing: Nature exists. I saw that the trees, the rivers and the stones are things that truly exist. No one had ever thought about this.**

**I don’t pretend to be anything more than the greatest poet in the world. I made the greatest discovery worth making, next to which all other discoveries are games of stupid children. I noticed the Universe. The Greeks, with all their visual acuity, didn’t do as much.**

## From THE KEEPER OF SHEEP
### Page 31 @ 28 June 2023 01:29:25 PM
<u>(What a sham! What do the flowers,<br/>
The trees and the sheep know<br/>
About St. Barbara? … The branch of a tree,<br/>
If it could think, would never<br/>
Invent saints or angels …<br/>
It might think that the sun<br/>
Illuminates and that thunder<br/>
Is a sudden noise<br/>
That begins with light …<br/>
Ah, how even the simplest men<br/>
Are sick and confused and stupid<br/>
Next to the sheer simplicity<br/>
And healthy existence<br/>
Of plants and trees!)</u>

### Page 32 @ 28 June 2023 01:33:28 PM
To think about God is to disobey God,
Since God wanted us not to know him,
Which is why he didn’t reveal himself to us …
 
Let’s be simple and calm,
Like the trees and streams,
And God will love us, making us Us even as the trees are trees
And the streams are streams,
And will give us greenness in the spring, which is its season,
And a river to go to when we end …
And he’ll give us nothing more, since to give us more would make us less us.

### Page 33 @ 28 June 2023 01:35:31 PM
<u>His father was two different people—<br/>
An old man named Joseph who was a carpenter<br/>
And who wasn’t his father,<br/>
And an idiotic dove:<br/>
The only ugly dove in the world,<br/>
Because it wasn’t of the world and wasn’t a dove.<br/>
And his mother gave birth to him without ever having loved.<br/>
She wasn’t a woman: she was a suitcase<br/>
In which he was sent from heaven.<br/>
And they wanted him, born only of a mother<br/>
And with no father he could love and honor,<br/>
To preach goodness and justice!</u>

### Page 34 @ 28 June 2023 01:37:35 PM
<u>He says God understands nothing<br/>
About the things he created.<br/>
“If he created them, which I doubt,” he says.<br/>
“God claims, for instance, that all beings sing his glory,<br/>
But beings don’t sing anything.<br/>
If they sang, they’d be singers.<br/>
Beings exist, that’s all,<br/>
Which is why they’re called beings.”</u>

### Page 35 @ 28 June 2023 01:38:39 PM
<u>The New Child who lives where I live<br/>
Gives one hand to me<br/>
And the other to everything that exists,<br/>
And so the three of us go along whatever road we find,<br/>
Leaping and singing and laughing<br/>
And enjoying our shared secret<br/>
Of knowing that in all the world<br/>
There is no mystery<br/>
And that everything is worthwhile.</u>

### Page 37 @ 28 June 2023 01:41:48 PM
**To think a flower is to see and smell it,
And to eat a fruit is to know its meaning.**

### Page 37 @ 28 June 2023 01:42:58 PM
Lightly, lightly, very lightly
A very light wind passes,
And it goes away just as lightly,
And I don’t know what I’m thinking,
Nor do I wish to know.

### Page 39 @ 28 June 2023 01:45:30 PM
<u>Sometimes, on days of perfect and exact light,<br/>
When things are as real as they can possibly be,<br/>
I slowly ask myself<br/>
Why I even bother to attribute<br/>
Beauty to things.</u>

### Page 41 @ 28 June 2023 01:50:38 PM
If you want me to have a mysticism, then fine, I have one.
I’m a mystic, but only with my body.
My soul is simple and doesn’t think.
 
My mysticism is not wanting to know.
It’s living and not thinking about it.
 
I don’t know what Nature is: I sing it.
I live on top of a hill In a solitary, whitewashed house,
And that is my definition.

### Page 42 @ 28 June 2023 01:53:20 PM
<u>The moonlight seen through the tall branches<br/>
Is more, say all the poets,<br/>
Than the moonlight seen through the tall branches.<br/>
<br/>
But for me, oblivious to what I think,<br/>
The moonlight seen through the tall branches,<br/>
Besides its being<br/>
The moonlight seen through the tall branches,<br/>
Is its not being more<br/>
Than the moonlight seen through the tall branches.</u>

### Page 43 @ 28 June 2023 01:56:27 PM
I think about this not as one who thinks but as one who doesn’t,
And I look at the flowers and smile …
I don’t know if they understand me
Or if I understand them,
But I know the truth is in them and in me
And in our common divinity
Of letting go and living right here on the Earth
And contentedly cuddling up in the Seasons
And letting the wind gently sing us to sleep
And having no dreams in our slumber.

### Page 44 @ 28 June 2023 01:58:46 PM
Better the flight of the bird that passes and leaves no trace
Than the passage of the animal, recorded in the ground.
The bird passes and is forgotten, which is how it should be.
The animal, no longer there and so of no further use,
Uselessly shows it was there.
 
Remembrance is a betrayal of Nature,
Because yesterday’s Nature isn’t Nature.
What was is nothing, and to remember is not to see.
 
Pass by, bird, pass, and teach me to pass!
 
7 MAY 1914

## From UNCOLLECTED POEMS
### Page 55 @ 29 June 2023 04:22:50 PM
<u>If the soul is more real<br/>
Than the outer world, as you, philosopher, say it is,<br/>
Then why was the outer world given to me as reality’s prototype?<br/>
If my feeling is more certain<br/>
Than the existence of the thing I feel,<br/>
Then why do I feel that thing and why does it appear<br/>
Independently of me,<br/>
Without needing me to exist—<br/>
Me, who am forever bound to myself, forever personal and nontransferable?</u>

### Page 56 @ 29 June 2023 04:22:30 PM
<u>We live before we philosophize, we exist before we know we do,<br/>
And the earlier fact merits at least homage and precedence.<br/>
Yes, we are outer before we are inner.<br/>
Therefore we are essentially outer.</u>

### Page 57 @ 29 June 2023 04:26:06 PM
<u>Humanity is an uprising of slaves.<br/>
Humanity is a government usurped by the people,<br/>
Existing because usurped, but erring, since to usurp is to have no right.<br/>
<br/>
Let the outer world and natural humanity be!<br/>
Peace to all prehuman things, including those in man!<br/>
Peace to the wholly outer essence of the Universe!</u>

### Page 58 @ 29 June 2023 04:28:13 PM
Hillside shepherd, so far away from me with your sheep,
Is the happiness you seem to have your happiness or mine?
Does the peace I feel when I see you belong to you or to me?
No, shepherd, neither to you nor to me.
It belongs only to peace and happiness.
You don’t have it, because you don’t know you have it,
And I don’t have it, because I know I do.
It exists on its own, and falls on us like the sun,
Which hits you on the back and warms you up, while you
indifferently think about something else,
And it hits me in the face and dazzles my eyes, and I think only about the sun.
 
12 APRIL 1919

## RICARDO REIS
### Page 68 @ 29 June 2023 04:42:24 PM
**Like the calm, implacable Destiny
That reigns above the gods,
Let’s construct a voluntary fate
Above ourselves,
So that when it oppresses us, it is we
Who’ll be our oppressors.
And when we enter the night, we’ll enter
By our own two feet.**

## THE CHESS PLAYERS
### Page 75 @ 29 June 2023 04:51:02 PM
<u>Securely I sit on the steadfast column<br/>
Of the verses in which I’ll remain,<br/>
Not fearing the endless future influx<br/>
Of times and of oblivion,<br/>
For when the mind intently studies<br/>
In itself the world’s reflections,<br/>
It becomes their plasma, and the world is what<br/>
Creates art, not the mind.  Thus<br/>
On the plaque the outer moment engraves<br/>
Its being, and there endures.</u>

### Page 76 @ 29 June 2023 04:53:10 PM
**I want the flower you are, not the one you give.
Why refuse me what I don’t ask of you?
You’ll have time to refuse
After you’ve given.
Flower, be a flower to me! If, ungenerous, you’re plucked
By the hand of the ill-omened sphinx, you’ll wander forever
As an absurd shadow,
Seeking what you never gave.**
 
21 OCTOBER 1923

### Page 79 @ 29 June 2023 05:05:32 PM
The leaf won’t return to the branch it left
Nor form a new leaf with the same stem.
The moment, which ends as this one begins,
Has died forever.
The vain and uncertain future promises
No more than this repeated experience
Of the mortal lot and the lost condition
Of things and of myself.
And so, in this universal river
Where I’m not a wave, but waves,
I languidly flow, with no requests
And no gods to hear them.
 
28 SEPTEMBER 1926

## EXCERPTS FROM TWO ODES
### Page 101 @ 30 June 2023 02:25:59 AM
Come faintly,
Come softly,
Come alone, solemn, with hands hanging
At your sides, come
And bring the far-off hills as near as the nearby trees,
Merge every field I see into your one field,
Make the mountain one more block of your body,
Erase all its differences I see from afar,
All the roads that climb it,
All the varied trees that make it dark green in the distance,
All the white houses whose smoke rises through the trees,
And leave just one light, and another light, and one more light
In the hazy and vaguely troubling distance,
In the distance that’s suddenly impossible to cross.

### Page 102 @ 30 June 2023 02:26:51 AM
**Come ever so solemnly,
Solemn and full
Of a secret desire to weep,
Perhaps because the soul is vast and life small,
And none of our gestures ever leaves our body,
And we can reach only as far as our arm reaches,
And can see only as far as our sight extends.**

## LISBON REVISITED (1926)
### Page 177 @ 30 June 2023 03:49:24 PM
**Ah, vanity of flesh and blood called man,
Can’t you see that you’re utterly unimportant?**

## LÀ-BAS, JE NE SAIS OÙ…
### Page 211 @ 30 June 2023 05:54:05 PM
<u>To be a beggar and a bum doesn’t mean you’re a beggar and a bum:<br/>
It means you’re unconnected to the social ladder,<br/>
It means you’re unadaptable to life’s norms,<br/>
To life’s real or sentimental norms—<br/>
It means you’re not a High Court judge, a nine to five<br/>
employee, or a whore,<br/>
Not genuinely poor or an exploited worker,<br/>
Not sick with an incurable disease,<br/>
Not thirsty for justice, or a cavalry officer,<br/>
Not, in short, within any of those social categories depicted by novelists<br/>
Who pour themselves out on paper because they have good reasons for shedding tears<br/>
And who rebel against society because their good reasons<br/>
make them think they’re rebels.</u>

## SENHOR SILVA
### Page 251 @ 01 July 2023 12:42:24 AM
**In this calm and stupid life,
I never know how I should act.
But, my God, I feel human pain!
Don’t ever deny me that!**

## From FAUST
### Page 294 @ 01 July 2023 01:29:26 AM
<u>Everything we see is something else.<br/>
The sweeping tide, the raging tide,<br/>
Is the echo of another tide that flows<br/>
Where the world is really real.<br/>
All we have is forgetfulness.</u>

---
Depndant origintion.



_Generated at: 2023-07-02-11-16-15_