---
{"tags":["reading-note","Reading"],"dg-publish":true,"dg-note-icon":"stone","title":"Notes from Animal Farm by George Orwell","created":"2026-03-16T18:10:07.962-10:00","updated":"2026-03-17T14:14:07.349-10:00","dg-path":"III. Reading/Notes and Highlights/Animal Farm by George Orwell","permalink":"/iii/","dgPassFrontmatter":true,"noteIcon":"stone"}
---






# Animal Farm
##### by George Orwell

## Chapter 10
### Page 91 @ August 27, 2017
ALL ANIMALS ARE EQUAL BUT SOME ANIMALS ARE MORE EQUAL THAN OTHERS

---
The punchline.