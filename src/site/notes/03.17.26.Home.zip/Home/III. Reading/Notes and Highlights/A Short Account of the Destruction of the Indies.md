---
{"title":"Notes from A Short Account of the Destruction of the Indies by Bartolome Las Casas","aliases":["Notes from A Short Account of the Destruction of the Indies by Bartolome Las Casas"],"updated":"2026-03-17T14:14:07.357-10:00","created":"2026-03-16T18:10:07.962-10:00","latitude":23.78280167,"longitude":90.42128,"altitude":-2.7,"dg-publish":true,"dg-note-icon":"stone","tags":["history","american","european","reading-notes-old","Reading","reading-note"],"dg-path":"III. Reading/Notes and Highlights/A Short Account of the Destruction of the Indies","permalink":"/iii/","dgPassFrontmatter":true,"noteIcon":"stone"}
---






# A Short Account of the Destruction of the Indies
##### Bartolome Las Casas
## Introduction
### 01 May 2022 04:35 PM
**The story is now a famous one. That morning a recent arrival on the island, the Dominican Antonio Montesinos, delivered a sermon in the church of Santo Domingo. Taking his text from St John, he drew an analogy between the natural desert in which the Evangelist had chosen to spend his life and the human desert which the Spaniards had made of the once fruitful, ‘paradisiacal’ island of Hispaniola. He then turned upon the colonists. ‘With what right, ’ he demanded of them, ‘and with what justice do you keep these poor Indians in such cruel and horrible servitude? By what authority have you made such detestable wars against these people who lived peacefully and gently on their own lands? Are these not men? Do they not have rational souls? Are you not obliged to love them as yourselves? ’ The last three questions were to become the referents of every subsequent struggle to defend the rights of the indigenous peoples of the Americas. For Las Casas, in particular, the third – ‘Are you not obliged to love them as yourselves? ’ – was to guide his actions for the rest of his life.**


### 01 May 2022 08:41 PM
In 1513, in an attempt to silence any further protest, the jurist Juan López de Palacios Rubios, one of King Ferdinand's ideologues, drew up a document known as the ‘Requirement’ (or Requerimiento). This began with a history of the world since Adam. It then moved swiftly on to the grant made by the Pope to the Castilian Crown and the obligation of every Indian to pay homage to the agents of the Crown and to obey their orders. It finished with a gruesome account of what would befall any Indian who refused to obey. Every conquistador was to carry a copy of this document with him and to read it, in the presence of a notary, before making an attack. The facts that the document was in Spanish, a language no Indian could then understand, that it made no attempt to explain the complex legal and theological terms in which it was expressed, and that it was frequently read at night to sleeping villages or out of earshot of the Indians (see pp. 33 and 56) were disregarded. What mattered was the act. Once the Europeans had discharged their duty to inform, the way was clear for pillage and enslavement. When asked what he thought of this, surely one of the crassest instances of legalism in European history, Las Casas replied that he did not know whether to laugh or to cry. But the Requerimiento was taken seriously enough. Pedrarias Dávila's expedition to Tierra Firme in 1513 (see p. 31) was held up for months while the document was drafted.


### 01 May 2022 09:20 PM
Not only did he agitate for the rights and better treatment of the Indians but he also defended their claim, which in the Spain of the mid-sixteenth century was constantly under surveillance, to be regarded as human beings. Ever since 1513, Las Casas had fought against the suggestion that the Indians might be some species of sub-human, the ‘natural slaves’ which Aristotle had suggested might exist somewhere [In the World](In%20the%20World) for the benefit of civilized men. His longest and most original work, the Apologetic History of the Indies, a vast comparative ethnology of the Americas, is precisely an extended attempt to demonstrate, beyond all shadow of empirical doubt, that the Indians were fully rational beings with a culture which, though certainly ‘primitive’ in its technology and in a large number of its cultural practices, was equal to anything which the Old World had produced.


## HISPANIOLA
### 02 May 2022 04:25 PM
They spared no one, erecting especially wide gibbets on which they could string their victims up with their feet just off the ground and then burn them alive thirteen at a time, in honour of our Saviour and the twelve Aposdes, or tie dry straw to their bodies and set fire to it.


## THE MAINLAND
### 02 May 2022 07:45 PM
**It is as though the Son of God, who gave His life for every living soul, when He instructed His followers with the words: ‘Go ye therefore, and teach all nations’, 42 intended heathens, living in peace and tranquillity in their own lands, to be confronted with a demand that they convert on the spot, without their ever hearing the Word or having Christian doctrine explained to them; and that, should they show any reluctance to do so and to swear allegiance to a king they have never heard of nor clapped eyes on, and whose subjects and ambassadors prove to be cruel, pitiless and bloodthirsty tyrants, they should immediately surrender all their worldly goods and lose all rights to their land, their freedom, their womenfolk, their children and their lives. Such a notion is as absurd as it is stupid and should be treated with the disrespect, scorn and contempt it so amply deserves.**