---
{"title":"House of Leaves","aliases":["House of Leaves"],"authors":["Mark Z. Danielewski"],"publisher":"Pantheon","publish":"2000","pages":742,"isbn10":"0375703764","isbn13":"9780375703768","rating":5,"reviewed":true,"cover":"https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1736622426i/21241860.jpg","read_count":1,"tags":["book","fiction","Reading","haveread"],"log":[{"status":"Read","timestamp":"2025-03-25T20:14:17+06:00"},{"status":"In Progress","timestamp":"2025-02-24T22:58:10+06:00"},{"status":"To Read","timestamp":"2025-02-24T22:05:03+06:00"}],"created":"2026-03-16T18:10:07.957-10:00","updated":"2026-03-17T14:14:06.975-10:00","status":"Read","dg-publish":true,"dg-note-icon":2,"reading_notes":"[Notes from House Of Leaves](House%20Of%20Leaves)","dg-path":"III. Reading/Have Read/House of Leaves by Mark Z Danielewski","permalink":"/iii/","dgPassFrontmatter":true,"noteIcon":2}
---






I consider myself a writer. However, I fear writing, and I fear publishing more. For writing is agonising. And, I don't dare to publish until I really have a story to tell. My fear accumulated over time by reading more, by reading books just like this. And, I will tell my fellow writers this: If you are not really as serious as Danielewski, Borges, Tagore, Pessoa, or Jibanananda, stop writing.

The structure of this book is recursive, layered and of a madman. It is a book you should approach with an arsenal of bookmarks, much patience for multiple re-readings and the intention to read cover-to-cover, footnotes and appendix and all. While some of the references in this book are purely fictional, many are real. It is not necessary, but some familiarity with classic literature and existential philosophy (resources like [Being and Time by Martin Heidegger](Home/III.%20Reading/Have%20Read/Being%20and%20Time%20by%20Martin%20Heidegger)) can be very rewarding. I will also recommend reading [Walking by Thomas Bernhard](Home/III.%20Reading/Have%20Read/Walking%20by%20Thomas%20Bernhard), which deals with madness singularly, unlike this book, which deals with a lot of things. A knack for etymology and the exact meaning of words can be rewarding, too.

Now about the madness… It is everywhere, and *it must be relished*. It must be understood on its own terms, not from our couch of comfortable 'normality'. Madness is, in some sense, divine. Madness is motherly. Madness is a concentrated potion, too hard to gulp down, of the essence of our existence. This book talks about **that** madness,[^1] and love,[^2] and madness-inducing love,[^3] and love-inducing madness.[^4]

Most readers of this book may find the preceding paragraph needs some qualifications. The book is considered to be of the horror genre, and rightly so. However, it is not a run-of-the-mill horror. I will put it in a sub-genre: **philosophical horror**. Because most horror content depends on unfamiliarity and not understanding of the situation, this book depends on understanding and examination. Instead of jump-scares and goosebumps, the author brings in elaborate discussion on meanings of words like 'uncanny', 'space', 'echo', etc., so that as the meanings sink in us in the most accurate and non-trivial manner, so does the horror of the situation.

But, in the end, it remains a story of love, seeking, remembering, hope, and redemption.

> [
<div class="transclusion internal-embed is-loaded"><div class="markdown-embed">




# Note


</div></div>
] Notes and Highlights
> [Notes from House Of Leaves](../Notes%20and%20Highlights/House%20Of%20Leaves)


> [!info] About [House Of Leaves](../Notes%20and%20Highlights/House%20Of%20Leaves) by Mark Z. Danielewski
> <img src="https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1736622426i/21241860.jpg" style="float: left; width: 150px; height: auto; margin-right: 1em;" /> THE MIND-BENDING CULT CLASSIC ABOUT A HOUSE THAT’S LARGER ON THE INSIDE THAN ON THE OUTSIDE • A masterpiece of horror and an astonishingly immersive, maze-like reading experience that redefines the boundaries of a novel. ''Simultaneously reads like a thriller and like a strange, dreamlike excursion into the subconscious." —Michiko Kakutani, The New York Times "Thrillingly alive, sublimely creepy, distressingly scary, breathtakingly intelligent—it renders most other fiction meaningless." —Bret Easton Ellis, bestselling author of American Psycho “This demonically brilliant book is impossible to ignore.” —Jonathan Lethem, award-winning author of Motherless Brooklyn One of The Atlantic’s Great American Novels of the Past 100 Years Years ago, when [House Of Leaves](../Notes%20and%20Highlights/House%20Of%20Leaves) was first being passed around, it was nothing more than a badly bundled heap of paper, parts of which would occasionally surface on the Internet. No one could have anticipated the small but devoted following this terrifying story would soon command. Starting with an odd assortment of marginalized youth—musicians, tattoo artists, programmers, strippers, environmentalists, and adrenaline junkies—the book eventually made its way into the hands of older generations, who not only found themselves in those strangely arranged pages but also discovered a way back into the lives of their estranged children. Now made available in book form, complete with the original colored words, vertical footnotes, and second and third appendices, the story remains unchanged. Similarly, the cultural fascination with [House Of Leaves](../Notes%20and%20Highlights/House%20Of%20Leaves) remains as fervent and as imaginative as ever. The novel has gone on to inspire doctorate-level courses and masters theses, cultural phenomena like the online urban legend of “the backrooms,” and incredible works of art in entirely unrealted mediums from music to video games. Neither Pulitzer Prize-winning photojournalist Will Navidson nor his companion Karen Green was prepared to face the consequences of the impossibility of their new home, until the day their two little children wandered off and their voices eerily began to return another story—of creature darkness, of an ever-growing abyss behind a closet door, and of that unholy growl which soon enough would tear through their walls and consume all their dreams.



[^1]: Of Zampano's, and Truant's.
[^2]: Of Navidson's, Karen's, and even Tom's.
[^3]: Of Truant's mother's.
[^4]: Of Thumper's.