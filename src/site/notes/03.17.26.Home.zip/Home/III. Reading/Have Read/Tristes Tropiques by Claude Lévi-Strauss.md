---
{"title":"Tristes Tropiques","created":"2026-03-16T18:10:07.960-10:00","updated":"2026-03-17T14:14:07.258-10:00","read_count":"1","authors":["Claude Lévi-Strauss","John Weightman","Doreen Weightman"],"isbn10":140165622,"rating":5,"reviewed":true,"dg-publish":true,"dg-note-icon":2,"cover":"https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1302750303i/283901.jpg","dg-metatags":{"og:image":"https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1302750303i/283901.jpg"},"tags":["anthropology","america","indian-subcontinent","european","Reading","haveread"],"log":[{"status":"Read","timestamp":"2022-01-19T00:00:00+06:00"},{"status":"To Read","timestamp":"2021-11-20T00:00:00+06:00"}],"status":"Read","reading_notes":"[Tristes Tropiques by Claude Lévi-Strauss](Home/III.%20Reading/Notes%20and%20Highlights/Tristes%20Tropiques%20by%20Claude%20Lévi-Strauss)","dg-path":"III. Reading/Have Read/Tristes Tropiques by Claude Lévi-Strauss","permalink":"/iii/","metatags":{"og:image":"https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1302750303i/283901.jpg"},"dgPassFrontmatter":true,"noteIcon":2}
---






# Note


</div></div>
] Notes and Highlights
> [Tristes Tropiques by Claude Lévi-Strauss](../Notes%20and%20Highlights/Tristes%20Tropiques%20by%20Claude%20Lévi-Strauss)

> [!info] About Tristes Tropiques by Claude Lévi-Strauss
><img src="https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1302750303i/283901.jpg" style="float: left; margin-right: 1em;width: 150px; height: auto;" /> Tristes Tropiques begins with the line ‘I hate travelling and explorers’, yet during his life Claude Lévi-Strauss travelled from wartime France to the Amazon basin and the dense upland jungles of Brazil, where he found ‘human society reduced to its most basic expression’. His account of the people he encountered changed the field of anthropology, transforming Western notions of ‘primitive’ man. Tristes Tropiques is a major work of art as well as of scholarship. It is a memoir of exquisite beauty and a masterpiece of travel writing: funny, discursive, movingly detailing personal and cultural loss, and brilliantly connecting disparate fields of thought. Few books have had as powerful and broad an impact.