---
{"title":"The Conference of the Birds","aliases":["The Conference of the Birds"],"authors":["Attar of Nishapur","Sholeh Wolpé (Translation)"],"publisher":"W. W. Norton & Company","publish":"2017-03-07","pages":3,"isbn10":"0393292193","isbn13":"9780393292190","rating":5,"reviewed":true,"cover":"https://books.google.com/books/publisher/content/images/frontcover/1kx8DAAAQBAJ?fife=w600-h900&source=gbs_api","read_count":"1","tags":["book","poetry","Reading","haveread"],"log":[{"status":"Read","timestamp":"2024-02-17T23:33:08+06:00"},{"status":"In Progress","timestamp":"2024-01-29T16:17:28+06:00"},{"status":"To Read","timestamp":"2024-01-29T16:16:16+06:00"}],"created":"2026-03-16T18:10:07.958-10:00","updated":"2026-03-17T14:14:07.068-10:00","status":"Read","dg-publish":true,"dg-note-icon":2,"reading_notes":"[The Conference of the Birds by Attar](Home/III.%20Reading/Notes%20and%20Highlights/The%20Conference%20of%20the%20Birds%20by%20Attar)","dg-path":"III. Reading/Have Read/The Conference of the Birds by Attar","permalink":"/iii/","dgPassFrontmatter":true,"noteIcon":2}
---






A seminal text of the Sufi literature. It influenced both thinkers and the writing styles of subsequent generations. As far as Sufi spiritualism is concerned, the content is timeless.

So, what is this book about? In Attar's words:


<div class="transclusion internal-embed is-loaded"><a class="markdown-embed-link" href="Reading/notes-and-highlights/the-conference-of-the-birds-by-attar/#bcbfff" aria-label="Open link"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="svg-icon lucide-link"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path></svg></a><div class="markdown-embed">

<div class="markdown-embed-title">

# The Conference of the Birds by Attar

</div>


This book is all madness.
Reason is alien to these pages.
Not until the soul breathes in
the fragrance of its own lunacy
can it stop being a stranger to itself. 

</div></div>


It is difficult to appreciate the accuracy of this statement without reading the book first.

Sufism is all about love. Unconditional, unfailing, love and submission. This brought the practitioners into broad daylight from a narrow tunnel of organised religion. Since they reject anything that is against love, they reject hatred and welcome even critical thinking to a certain extent.

The genius of Attar is manyfold. This is not a philosophical treaty. Philosophy was unimportant (mocked even) to Attar. What he wanted to convey was the journey of a Sufi (consisting of [Fanā](../../Entities/Concept/Sufism/Fana) and [Baqā](../../Entities/Concept/Sufism/Baqa)) and its emotional import. He did it with very accessible parables. Some of them are even borderline heresy, but all of them are beautiful.

It is amazing how well this book conveys the deeper meanings of Sufism that many weighty discourses cannot do.

> [
<div class="transclusion internal-embed is-loaded"><div class="markdown-embed">




# Note


</div></div>
] Notes and Highlights
> [The Conference of the Birds by Attar](../Notes%20and%20Highlights/The%20Conference%20of%20the%20Birds%20by%20Attar)

> [!info] About The Conference of the Birds by Attar
> <img src="https://books.google.com/books/publisher/content/images/frontcover/1kx8DAAAQBAJ?fife=w600-h900&source=gbs_api" style="float: left; width: 150px; height: auto; margin-right: 1em;" /> “These lofty words are an antidote for anyone sickened by extremism's poison.” Considered by Rumi to be “the master” of Sufi mystic poetry, Attar is best known for this epic poem, a magnificent allegorical tale about the soul’s search for meaning. He recounts the perilous journey of the world’s birds to the faraway peaks of Mount Qaf in search of the mysterious Simorgh, their king. Attar’s beguiling anecdotes and humor intermingle the sublime with the mundane, the spiritual with the worldly, while his poem models the soul’s escape from the mind’s rational embrace. Sholeh Wolpé re-creates for modern readers the beauty and timeless wisdom of the original Persian, in contemporary English verse and poetic prose.