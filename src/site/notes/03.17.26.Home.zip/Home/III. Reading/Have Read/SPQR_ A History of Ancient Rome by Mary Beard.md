---
{"title":"SPQR: A History of Ancient Rome","created":"2026-03-16T18:10:07.957-10:00","updated":"2026-03-17T14:14:07.015-10:00","read_count":"1","authors":["Mary Beard"],"isbn10":1631492225,"rating":4,"reviewed":true,"tags":["european","history","politics","pop","roman","Reading","haveread"],"cover":"https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1470421195i/28789711.jpg","dg-publish":true,"dg-note-icon":1,"dg-metatags":{"og:image":"https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1470421195i/28789711.jpg"},"log":[{"status":"Read","timestamp":"2020-07-16T00:00:00+06:00"},{"status":"To Read","timestamp":"2020-05-27T00:00:00+06:00"}],"status":"Read","reading_notes":"[SPQR: A History of Ancient Rome](SPQR_%20A%20History%20of%20Ancient%20Rome)","dg-path":"III. Reading/Have Read/SPQR_ A History of Ancient Rome by Mary Beard","permalink":"/iii/","metatags":{"og:image":"https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1470421195i/28789711.jpg"},"dgPassFrontmatter":true,"noteIcon":1}
---






> [
<div class="transclusion internal-embed is-loaded"><div class="markdown-embed">




# Note


</div></div>
] Notes and Highlights
> [SPQR: A History of Ancient Rome](../Notes%20and%20Highlights/SPQR_%20A%20History%20of%20Ancient%20Rome)

> [!info] About SPQR by Mary Beard
> <img src="https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1470421195i/28789711.jpg" style="float: left; width: 150px; height: auto; margin-right: 1em;" /> Sunday Times Top 10 BestsellerShortlisted for a British Book Industry Book of the Year Award 2016The new series Ultimate Rome: Empire Without Limit is on BBC2 nowAncient Rome matters.Its history of empire, conquest, cruelty and excess is something against which we still judge ourselves. Its myths and stories - from Romulus and Remus to the Rape of Lucretia - still strike a chord with us. And its debates about citizenship, security and the rights of the individual still influence our own debates on civil liberty today.SPQR is a new look at Roman history from one of the world's foremost classicists. It explores not only how Rome grew from an insignificant village in central Italy to a power that controlled territory from Spain to Syria, but also how the Romans thought about themselves and their achievements, and why they are still important to us. Covering 1,000 years of history, and casting fresh light on the basics of Roman culture from slavery to running water, as well as exploring democracy, migration, religious controversy, social mobility and exploitation in the larger context of the empire, this is a definitive history of ancient Rome.SPQR is the Romans' own abbreviation for their state: Senatus Populusque Romanus, 'the Senate and People of Rome'.