---
{"title":"Between the World and Me","created":"2026-03-16T18:10:07.956-10:00","updated":"2026-03-17T14:14:06.915-10:00","read_count":"1","authors":["Ta-Nehisi Coates"],"cover":"https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1451435027i/25489625.jpg","dg-metatags":{"og:image":"https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1451435027i/25489625.jpg"},"rating":5,"reviewed":true,"dg-publish":true,"log":[{"status":"Read","timestamp":"2019-08-10T00:00:00+06:00"},{"status":"To Read","timestamp":"2019-08-03T00:00:00+06:00"}],"tags":["african","america","bestreads","Reading","haveread"],"status":"Read","reading_notes":"[Between the World and Me by Ta-Nehisi Coates](Between%20the%20World%20and%20Me%20by%20Ta_%20Nehisi%20Coates)","dg-path":"III. Reading/Have Read/Between the World and Me by Ta-Nehisi Coates","permalink":"/iii/","metatags":{"og:image":"https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1451435027i/25489625.jpg"},"dgPassFrontmatter":true,"noteIcon":"1"}
---






A first-hand account of what it means to be an African-American in our time. Profound, penetrating, moving yet tranquil in tone.

> [
<div class="transclusion internal-embed is-loaded"><div class="markdown-embed">




# Note


</div></div>
] Notes and Highlights
> [Between the World and Me by Ta-Nehisi Coates](../Notes%20and%20Highlights/Between%20the%20World%20and%20Me%20by%20Ta_%20Nehisi%20Coates)

> [!info] About Between the World and Me by Ta-Nehisi Coates
> <img src="https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1451435027i/25489625.jpg" style="float: left; width: 150px; height: auto; margin-right: 1em;" /> Between the World and Me is Ta-Nehisi Coates’s attempt to answer these questions in a letter to his adolescent son. Coates shares with his son—and readers—the story of his awakening to the truth about his place [In the World](../Notes%20and%20Highlights/In%20the%20World) through a series of revelatory experiences, from Howard University to Civil War battlefields, from the South Side of Chicago to Paris, from his childhood home to the living rooms of mothers whose children’s lives were taken as American plunder. Beautifully woven from personal narrative, reimagined history, and fresh, emotionally charged reportage, Between the World and Me clearly illuminates the past, bracingly confronts our present, and offers a transcendent vision for a way forward.

