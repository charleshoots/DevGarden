---
{"title":"Against Interpretation and Other Essays","created":"2026-03-16T18:10:07.955-10:00","updated":"2026-03-17T14:14:06.855-10:00","read_count":"1","cover":"https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1436152896i/52374.jpg","authors":["Susan Sontag"],"isbn10":312280866,"rating":5,"reviewed":true,"log":[{"status":"Read","timestamp":"2021-12-08T00:00:00+06:00"},{"status":"To Read","timestamp":"2019-11-22T00:00:00+06:00"}],"dg-publish":true,"dg-metatags":{"og:image":"https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1436152896i/52374.jpg"},"tags":["america","art","european","literature","cinema","plays","criticism","language","Reading","haveread"],"status":"Read","reading_notes":"[Against Interpretation and Other Essays by Susan Sontag](Against%20Interpretation%20and%20Other%20Essays%20by%20Susan%20S)","dg-path":"III. Reading/Have Read/Against Interpretation and Other Essays by Susan Sontag","permalink":"/iii/","metatags":{"og:image":"https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1436152896i/52374.jpg"},"dgPassFrontmatter":true,"noteIcon":"1"}
---






> [
<div class="transclusion internal-embed is-loaded"><div class="markdown-embed">




# Note


</div></div>
] Notes and Highlights
> [Against Interpretation and Other Essays by Susan Sontag](../Notes%20and%20Highlights/Against%20Interpretation%20and%20Other%20Essays%20by%20Susan%20S)

> [!info] About Against Interpretation and Other Essays by Susan Sontag
><img src="https://books.google.com/books/content?id=HLdQPwAACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api" style="float: left; margin-right: 1em;width: 150px; height: auto;" /> 'A dazzling intellectual performance' Vogue Against Interpretation was Susan Sontag's first collection of essays and made her name as one of the most incisive thinkers of our time. Sontag was among the first critics to write about the intersection between 'high' and 'low' art forms, and to give them equal value as valid topics, shown here in her epoch-making pieces 'Notes on Camp' and 'Against Interpretation'. Here too are impassioned discussions of Sartre, Camus, Simone Weil, Godard, Beckett, Lévi-Strauss, science-fiction movies, psychoanalysis and contemporary religious thought. Originally published in 1966, this collection has never gone out of print and has been a major influence on generations of readers, and the field of cultural criticism, ever since. 'Sontag offers enough food for thought to satisfy the most intellectual of appetites' The Times