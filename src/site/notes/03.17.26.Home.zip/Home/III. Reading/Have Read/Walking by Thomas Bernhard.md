---
{"title":"Walking","authors":["Thomas Bernhard"],"publisher":"University of Chicago Press","publish":"2015-10-15","pages":97,"isbn10":"022631104X","isbn13":9780226311043,"rating":3,"reviewed":false,"cover":"https://books.google.com/books/content?id=4d4pCwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api","read_count":"1","tags":["fiction","Reading","haveread"],"created":"2026-03-16T18:10:07.960-10:00","log":[{"status":"Read","timestamp":"2023-04-13T03:23:44+06:00"},{"status":"In Progress","timestamp":"2023-04-08T11:49:16+06:00"},{"status":"To Read","timestamp":"2022-12-28T19:04:42+06:00"}],"updated":"2026-03-17T14:14:07.273-10:00","status":"Read","dg-publish":true,"dg-note-icon":1,"reading_notes":"[Walking by Thomas Bernhard](Garden/III.%20Reading/Notes%20and%20Highlights/Walking%20by%20Thomas%20Bernhard)","dg-path":"III. Reading/Have Read/Walking by Thomas Bernhard","permalink":"/iii/","dgPassFrontmatter":true,"noteIcon":1}
---






Modern literature is less about the content, and more about the representation. It is only expected that such works won't share fluency with *pop* works. However, these works almost always have other motives than telling a good story. In the case of this book, I couldn't understand what the motive was.

> [
<div class="transclusion internal-embed is-loaded"><div class="markdown-embed">




# Note


</div></div>
] Notes and Highlights
> [Walking by Thomas Bernhard](../Notes%20and%20Highlights/Walking%20by%20Thomas%20Bernhard)

> [!info] About Walking by Thomas Bernhard
><img src="https://books.google.com/books/content?id=4d4pCwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api" style="float: left; margin-right: 1em;width: 150px; height: auto;" /> "Walking records the conversations of the unnamed narrator and his friend Oehler while they walk, discussing anything that comes to mind but always circling back to their mutual friend Karrer, who has gone irrevocably mad."--Amazon.com.