---
{"title":"The Three-Body Problem","aliases":["The Three-Body Problem"],"authors":["Cixin Liu"],"publisher":"","publish":"2021-04","pages":448,"isbn10":"1800246684","isbn13":"9781800246683","rating":5,"reviewed":false,"cover":"https://books.google.com/books/publisher/content/images/frontcover/7zzZzQEACAAJ?fife=w600-h900&source=gbs_api","read_count":1,"series":{"rem_ep":1},"tags":["book","science-fiction"],"log":[{"status":"Read","timestamp":"2025-01-15T04:09:44+06:00"},{"status":"In Progress","timestamp":"2024-12-07T02:11:52+06:00"},{"status":"To Read","timestamp":"2024-02-11T15:55:33+06:00"}],"created":"2026-02-04T07:22:02.000-10:00","updated":"2026-02-07T23:58:17.938-10:00","status":"Read","dg-publish":true,"dg-note-icon":1,"reading_notes":"[The Three-Body Problem](The%20Three-Body%20Problem)","dg-path":"III. Reading/Have Read/The Three-Body Problem by Liu Cixin","permalink":"/iii-reading/have-read/the-three-body-problem-by-liu-cixin/","dgPassFrontmatter":true,"noteIcon":1}
---


> [!HINT] Impressions
> Precision, philosophical, expansive, intricate, not-so-pop science.

The first thing I noticed about this book is the scientific precision, to be specific. The images are only the vehicle of bigger ideas and are minimal in composition. The prose is seldom descriptive of the environment. Tantalising technologies almost play no role in this work. Instead, their implications have been discussed heavily.

Like any sophisticated science-fiction, this one makes philosophy *story-able*. And that storyscape unfurled over a large expanse of space and time.

> [!note] Notes and Highlights
> [The Three-Body Problem](../Notes%20and%20Highlights/The%20Three-Body%20Problem)

> [!info] About The Three-Body Problem by Liu Cixin
> <img src="https://books.google.com/books/publisher/content/images/frontcover/7zzZzQEACAAJ?fife=w600-h900&source=gbs_api" style="float: left; width: 150px; height: auto; margin-right: 1em;" /> After a spate of apparent suicides among elite scientists, nanotech engineer Wang Miao is asked to infiltrate a secretive cabal. During his investigation, Wang is inducted into a mysterious online game that is the key to humanity's place in the cosmos and the key to the extinction-level threat it now faces.