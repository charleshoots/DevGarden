---
{"title":"Silence","created":"2026-03-16T18:10:07.957-10:00","updated":"2026-03-17T14:14:07.028-10:00","read_count":"1","authors":["Shūsaku Endō","William Johnston"],"isbn10":800871863,"rating":5,"reviewed":true,"cover":"https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1503294393i/25200.jpg","dg-metatags":{"og:image":"https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1503294393i/25200.jpg"},"dg-publish":true,"dg-note-icon":3,"tags":["Christianity","Japanese","novel","Reading","haveread"],"log":[{"status":"Read","timestamp":"2022-04-06T00:00:00+06:00"},{"status":"To Read","timestamp":"2021-07-03T00:00:00+06:00"}],"status":"Read","reading_notes":"[Silence by Shūsaku Endō](Home/III.%20Reading/Notes%20and%20Highlights/Silence%20by%20Shūsaku%20Endō)","dg-path":"III. Reading/Have Read/Silence by Shūsaku Endō","permalink":"/iii/","metatags":{"og:image":"https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1503294393i/25200.jpg"},"dgPassFrontmatter":true,"noteIcon":3}
---






Except for *[Barabbas](Barabbas%20by%20Pär%20Lagerkvist)* this is the only *~~Christian novel~~ theologico-historical novel[^1]* I read. And it's from another side of the globe from *Barabbas*.

While this novel has been labeled as a novel about the atrocious persecution of Christians in Japan, to my understanding that is a backdrop, a very important backdrop, but backdrop still. It's also very complex. Official view about Christianity and elaborate tortures, the metamorphosis of the faith in the Japanese soil, the people, places, and nature… It's not a black-and-white story of oppression. 

This is predominantly a novel about Christian sympathy. A person's journey through suffering to understand what it meant to Christ, and what sort of shepherd he was. The central character (a priest) has gone through what we can say *'a dark night of the soul'*. The crisis was acute. Suffering raised questions that at other times can be considered blasphemous. This crisis is the origin of the name of this book. The unbearable silence of God in the face of the unbearable agony of layman Christians was a recurring theme. A particularly beautiful example of this crisis is:


<div class="transclusion internal-embed is-loaded"><a class="markdown-embed-link" href="Reading/notes-and-highlights/silence-by-shusaku-endo/#f6130b" aria-label="Open link"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="svg-icon lucide-link"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path></svg></a><div class="markdown-embed">



What do I want to say? I myself do not quite understand. Only that today, when for the glory of God Mokichi and Ichizo moaned, suffered and died, I cannot bear the monotonous sound of the dark sea gnawing at the shore. Behind the depressing silence of this sea, the silence of God. … the feeling that while men raise their voices in anguish God remains with folded arms, silent. 

</div></div>


It, in time, led the priest into doubt if God exists at all. Of course, his training in the seminary won.

What I liked about this book is how the priest was officially apostatized. He hasn't been broken down in extreme situations. Neither torture nor persuasion could convince him to apostatize. What convinced him is a deeper, more beautiful interpretation of the Christian faith. He found that even Christ himself would've been apostatized if it saved some souls from suffering.


<div class="transclusion internal-embed is-loaded"><a class="markdown-embed-link" href="Reading/notes-and-highlights/silence-by-shusaku-endo/#29faf0" aria-label="Open link"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="svg-icon lucide-link"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path></svg></a><div class="markdown-embed">



‘Don’t deceive yourself! ’ said Ferreira. ‘Don’t disguise your own weakness with those beautiful words. ’
‘My weakness? ’ The priest shook his head; yet he had no self-confidence. ‘What do you mean? It’s because I believe in the salvation of these people … ’
‘You make yourself more important than them. You are preoccupied with your own salvation. If you say that you will apostatize, those people will be taken out of the pit. They will be saved from suffering. And you refuse to do so. It’s because you dread to betray the Church. You dread to be the dregs of the Church, like me.’ Until now Ferreira’s words had burst out as a single breath of anger, but now his voice gradually weakened as he said: ‘Yet I was the same as you. On that cold, black night I, too, was as you are now. And yet is your way of acting love? A priest ought to live in imitation of Christ. If Christ were here … ’ For a moment Ferreira remained silent; then he suddenly broke out in a strong voice: ‘Certainly Christ would have apostatized for them. ’ 

</div></div>


This was the end of his dark night of the soul. The new dawn was not a dawn devoid of faith. Quite the contrary. It was a dawn bringing a faith deeper than anything he had ever learned.

Since I have not read it in Japanese, I can't talk about Endō's writing quality with much confidence. However, I think readers will agree with me on his ability to create symbolic archetypal characters whose importance lies in their manifestation of one quality, or vice, or a crisis. Over and over again throughout the book, they play the same role of a coward, kind, or heroic person. The book contains some such very powerful archetypes.

His intellectual honesty is particularly praiseworthy. He understood the problem of a foreign religion such as Christianity must face in a culture that is in many cases diametrically opposite to its European counterpart. Japanese empire was as oppressive as any of that time. Buddhism in their hand is just another justification to oppress and no solace to the poot. On the other hand,  European seafarers are not very bright example of Christianity. However, the love of Christ have some appeal to the unloved ones. Brutality and suppression are just side effects. The problem is deeper, and Endō faced it with much sincerity.

> [
<div class="transclusion internal-embed is-loaded"><div class="markdown-embed">




# Note


</div></div>
] Notes and Highlights
> [Silence by Shūsaku Endō](../Notes%20and%20Highlights/Silence%20by%20Shūsaku%20Endō)

> [!info] About Silence by Shūsaku Endō
> <img src="https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1503294393i/25200.jpg" style=" float: left; width: 150px; height: auto; margin-right: 1em;" /> Silence is a 1966 novel of theological and historical fiction by Japanese author Shūsaku Endō. It tells the story of a Jesuit missionary sent to 17th century Japan, who endures persecution in the time of Kakure Kirishitan that followed the defeat of the Shimabara Rebellion.

[^1]: Initially, I used the term 'Christian Novel' to both this and Barabbas like most other people. However, I believe, this term is narrow in scope, emphasize on the propaganda part more than the aesthetics, and doesn't do full justice to these works.