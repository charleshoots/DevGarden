---
{"title":"Weapons of Math Destruction: How Big Data Increases Inequality and Threatens Democracy","created":"2026-03-16T18:10:07.960-10:00","updated":"2026-03-17T14:14:07.286-10:00","read_count":"1","authors":["Cathy O'Neil"],"isbn10":553418815,"reviewed":true,"rating":5,"cover":"https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1456091964i/28186015.jpg","dg-metatags":{"og:image":"https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1456091964i/28186015.jpg"},"tags":["ai","computer-science","programming","science","Reading","haveread"],"log":[{"status":"Read","timestamp":"2019-11-12T00:00:00+06:00"},{"status":"To Read","timestamp":"2019-05-31T00:00:00+06:00"}],"status":"Read","dg-publish":true,"dg-note-icon":2,"reading_notes":"[Weapons of Math Destruction](Weapons%20of%20Math%20Destruction)","dg-path":"III. Reading/Have Read/Weapons of Math Destruction by Cathy O_Neil","permalink":"/iii/","metatags":{"og:image":"https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1456091964i/28186015.jpg"},"dgPassFrontmatter":true,"noteIcon":2}
---






This, I think, is one of the most important books I've read this year. For, one cannot expect to grasp even the most sketchy outline of our socio-economic reality if one is not familiar with the now-prevailing currency, namely data.  
  
The computer is good at doing things fast, really fast. So, when it errs, it errs in a flash, resulting in a gigantic accumulation of errors. It shouldn't be surprising that big data (a match made between statistics and computer science) with its inbuilt measures of inaccuracies paired with shortcomings in creating mathematical models that sufficiently mirror reality will create tools of horrible injustice. It is not always easy to notice. Technical difficulties and self-fulfilling feedback loops can deceive us quickly.  
  
However, the writer herself has been deep in this system and saw these things closely. With her deep knowledge and very conscientious mind, she is well-equipped to discuss the matter in great depth and honesty.

> [
<div class="transclusion internal-embed is-loaded"><div class="markdown-embed">




# Note


</div></div>
] Notes and Highlights
> [Weapons of Math Destruction](../Notes%20and%20Highlights/Weapons%20of%20Math%20Destruction)

> [!info] About [Weapons of Math Destruction](../Notes%20and%20Highlights/Weapons%20of%20Math%20Destruction) by Cathy O'Neil
> <img src="https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1456091964i/28186015.jpg" style="float: left; width: 150px; height: auto; margin-right: 1em;" /> NEW YORK TIMES BESTSELLER • A former Wall Street quant sounds the alarm on Big Data and the mathematical models that threaten to rip apart our social fabric—with a new afterword “A manual for the twenty-first-century citizen … relevant and urgent.”—Financial Times NATIONAL BOOK AWARD LONGLIST • NAMED ONE OF THE BEST BOOKS OF THE YEAR BY The New York Times Book Review • The Boston Globe • Wired • Fortune • Kirkus Reviews • The Guardian • Nature • On Point We live in the age of the algorithm. Increasingly, the decisions that affect our lives—where we go to school, whether we can get a job or a loan, how much we pay for health insurance—are being made not by humans, but by machines. In theory, this should lead to greater fairness: Everyone is judged according to the same rules. But as mathematician and data scientist Cathy O’Neil reveals, the mathematical models being used today are unregulated and uncontestable, even when they’re wrong. Most troubling, they reinforce discrimination—propping up the lucky, punishing the downtrodden, and undermining our democracy in the process. Welcome to the dark side of Big Data.
