---
{"title":"The Hero With a Thousand Faces","created":"2026-03-16T18:10:07.959-10:00","updated":"2026-03-17T14:14:07.105-10:00","read_count":"1","cover":"https://i.gr-assets.com/images/S/compressed.photo.goodreads.com/books/1442885694l/588138._SY475_.jpg","authors":["Joseph Campbell"],"isbn10":691017840,"rating":5,"reviewed":true,"dg-publish":true,"dg-note-icon":3,"tags":["anthropology","myth","psychology","Reading","haveread"],"dg-metatags":{"og:image":"https://i.gr-assets.com/images/S/compressed.photo.goodreads.com/books/1442885694l/588138._SY475_.jpg"},"log":[{"status":"Read","timestamp":"2019-01-20T00:00:00+06:00"},{"status":"To Read","timestamp":"2018-08-13T00:00:00+06:00"}],"status":"Read","reading_notes":"[The Hero With a Thousand Faces](The%20Hero%20With%20a%20Thousand%20Faces)","dg-path":"III. Reading/Have Read/The Hero With a Thousand Faces by Joseph Campbell","permalink":"/iii/","metatags":{"og:image":"https://i.gr-assets.com/images/S/compressed.photo.goodreads.com/books/1442885694l/588138._SY475_.jpg"},"dgPassFrontmatter":true,"noteIcon":3}
---






As the name suggests, this book is a synopsis of the basic personality of a hero (and the myth revolving around him) who can be identified across various cultures and mythologies with astonishing similarities. This is also a book of the idea of mythology how Joseph Campbell has seen.  
  
Now, though [Joseph Campbell](../../Entities/Person/Joseph%20Campbell) himself is a believer, he can’t help but notice that the old world of gods and demons, magic and might is falling and a new era of science and technology has emerged. But as he justifiably lamented in [The Power of Myth](../Notes%20and%20Highlights/The%20Power%20of%20Myth#^dcccd1), this new age had no powerful myth to support human through the generic darkness and existential crisis that almost everyone goes through. Nevertheless, this is not an apologist book to justify religion or faith, but a scholarly and pleasing journey through the world of myth.  
  
In this book, Campbell used ideas from psychoanalysis heavily to predict the possible origin of myths. The uncanny similarities between many neurotics’ dreams have compelled him to conclude that:


<div class="transclusion internal-embed is-loaded"><a class="markdown-embed-link" href="Reading/notes-and-highlights/the-hero-with-a-thousand-faces/#1a6dea" aria-label="Open link"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="svg-icon lucide-link"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path></svg></a><div class="markdown-embed">



Dream is the personalized myth, myth the depersonalized dream; 

</div></div>

  
Or, in another place:  


<div class="transclusion internal-embed is-loaded"><a class="markdown-embed-link" href="Reading/notes-and-highlights/the-hero-with-a-thousand-faces/#d9fcc4" aria-label="Open link"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="svg-icon lucide-link"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path></svg></a><div class="markdown-embed">



Mythology, in other words, is psychology misread as biography; history, and cosmology. 

</div></div>
  

Now, in this scope, in this domain of subjective reality and experience, the historical truth behind a myth is irrelevant, religion is somewhat less necessary.  
  
Mythology, the way he has seen, is not something that expresses the truth or the ultimate. It simply gives a vibe of that. Taking these symbols literally only diminish their meaning:


<div class="transclusion internal-embed is-loaded"><a class="markdown-embed-link" href="Reading/notes-and-highlights/the-hero-with-a-thousand-faces/#ddc8e9" aria-label="Open link"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="svg-icon lucide-link"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path></svg></a><div class="markdown-embed">



Symbols are only the vehicles of communication; they must not be mistaken for the final term, the tenor , of their reference. No matter how attractive or impressive they may seem, they remain but convenient means, accommodated to the understanding. 

</div></div>


<div class="transclusion internal-embed is-loaded"><a class="markdown-embed-link" href="Reading/notes-and-highlights/the-hero-with-a-thousand-faces/#0da9bb" aria-label="Open link"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="svg-icon lucide-link"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path></svg></a><div class="markdown-embed">



Mistaking a vehicle for its tenor may lead to the spilling not only of valueless ink, but of valuable blood. 

</div></div>


And by referencing myths from both very smaller tribal population to mega-religions he has indeed well-established the point.  
  
At the end, he predicted the decline of the world of myth and new possibilities. The idea he held of about the modern way of a meaningful life is more or less a [rephrasing of individualism](../../Entities/Person/Joseph%20Campbell#^a99897):  


<div class="transclusion internal-embed is-loaded"><a class="markdown-embed-link" href="Reading/notes-and-highlights/the-hero-with-a-thousand-faces/#053775" aria-label="Open link"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="svg-icon lucide-link"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path></svg></a><div class="markdown-embed">



And so every one of us shares the supreme ordeal—carries the cross of the redeemer—not in the bright moments of his tribe’s great victories, but in the silences of his personal despair. 

</div></div>
  

Now, many of the things he said may not have the same degree of truth it had once. Psychology and Neurology had walked a long way after his time and many ideas he may have believed are not true. But wise men are wise because they broke through the barrier of thoughts of their time, but not for some absolute truths they’ve spoken. Nevertheless, the book is an amazing read. His storytelling and knowledge of myth are awe-striking. Enjoyed the book, totally.

> [
<div class="transclusion internal-embed is-loaded"><div class="markdown-embed">




# Note


</div></div>
] Notes and Highlights
> [The Hero With a Thousand Faces](../Notes%20and%20Highlights/The%20Hero%20With%20a%20Thousand%20Faces)

> [!info] About [The Hero With a Thousand Faces](../Notes%20and%20Highlights/The%20Hero%20With%20a%20Thousand%20Faces) by Joseph Campbell
><img src="https://books.google.com/books/content?id=I1uFuXlvFgMC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api" style="float: left; margin-right: 1em;width: 150px; height: auto;" /> Discusses the universal legend of the hero in world mythology, focusing on the motif of the hero's journey through adventure and transformation.
