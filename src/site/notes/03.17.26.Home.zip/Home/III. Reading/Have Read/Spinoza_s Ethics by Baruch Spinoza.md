---
{"title":"Spinoza's Ethics","created":"2026-02-04T07:22:02.000-10:00","updated":"2026-02-07T23:58:17.941-10:00","read_count":"1","dg-publish":true,"dg-metatags":{"og:image":"https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1570444178i/45358700.jpg"},"cover":"https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1570444178i/45358700.jpg","authors":["Baruch Spinoza","George Eliot","Clare Carlisle"],"isbn10":"069119324X","rating":3,"dg-note-icon":2,"reviewed":true,"tags":["philosophy","ethics","theology","classic"],"log":[{"status":"Read","timestamp":"2021-08-04T00:00:00+06:00"},{"status":"To Read","timestamp":"2021-07-14T00:00:00+06:00"}],"status":"Read","reading_notes":"[Spinoza's Ethics by George Elliot](Spinoza_s%20Ethics%20by%20George%20Elliot)","dg-path":"III. Reading/Have Read/Spinoza_s Ethics by Baruch Spinoza","permalink":"/iii-reading/have-read/spinoza-s-ethics-by-baruch-spinoza/","metatags":{"og:image":"https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1570444178i/45358700.jpg"},"dgPassFrontmatter":true,"noteIcon":2}
---


অথোরিটিটিভ অনুবাদ বলতে যা বোঝায়, জর্জ এলিয়টের অনুবাদটি তা না। আবার এও না যে এলিয়ট নিজের মত করে অনুবাদ করে স্পিনোজাকে হারিয়ে ফেলেছেন। সে যাই হোক, এটা ঐতিহাসিকভাবে গুরুত্বপূর্ণ একটি অনুবাদ। আর যারা এটি প্রকাশ করেছেন সদ্য তারা যথেষ্ট টীকার মাধ্যমে অথোরিটিটিভ অনুবাদের সাথে পার্থক্য অনেকটাই কমিয়ে এনেছেন। বইয়ের ভূমিকাটা বড় এবং অপ্রয়োজনীয় মনে হলেও আসলে কাজটাকে সঠিক দৃষ্টিভঙ্গিতে দেখতে সাহায্য করবে।

স্পিনোজা’র এথিক্সের মূলে তার মেটাফিজিক্স। সেই মেটাফিজিক্সে গড এবং নেচারের মধ্যে পার্থক্য করা বেশ দুরূহ, যদিও পার্থক্য বিদ্যমান। মোটের ওপর স্পিনোজার গড হচ্ছে সেই সয়ম্ভূ সত্ত্বা যার ক্ষমতা, ব্যাপ্তি সমস্তকিছু অপরিসীম। সে সমস্ত গুণের অধিকারই শুধু না, তার গুণাতীত কিছু নাই। তাকে ব্যাতীত কোনো বাস্তবতাও নাই। বস্তুত, আমাদের সকল বাস্তবতা তার বাস্তবতার বিভিন্নরূপ। সেই অর্থে ধরলে আমাদের সবকিছুই মায়া।[^1]

স্পিনোজার মতে গড পারফেক্ট বলা চলে তখনই যখন সে সর্বশক্তিমান। অর্থাৎ সে যা চায় তা করার মাধ্যমেই তার পারফেক্টনেস প্রমাণিত হয়। এতএব সে যা যা করতে পারে তার চুলপরিমাণ কম করার সুযোগ তার নেই। তাতে তার ইশ্বরত্বের হানি ঘটে। সেদিক থেকে স্পিনোজার কসমোলজি পুরোপুরি ডিটারমিনিস্টিক। এবং এই ডিটারমিনিস্টিক নেচার একই সাথে গডের ক্ষমতা ও লিমিটেশন তৈরী করে। প্রথাগত আব্রাহামিক ধর্মের থেকে স্পিনোজার থিওলজির পার্থক্য মোটামুটি এইখানে সবচেয়ে প্রবল।[^2]

তাছাড়া স্পিনোজার গড অ্যান্থ্রোমরফিক না। সে কাউকে ভালোও বাসে না, ঘৃণাও করে না। প্রার্থনাও শোনে না, অস্বীকার করলে রাগও করে না। সে শুধু তার দ্বারা যা কিছু করা সম্ভব সবই করে।

মোটের ওপর আমার যা মনে হয়েছে, স্পিনোজা যেভাবে গডকে দেখে তাতে গড ছাড়াই দিব্যি একটা এথিকস্ দাঁড় করানো যেত। এই অতিরিক্ত কম্প্লিকেশন তার ব্যক্তিগত বিশ্বাসের জন্য হতে পারে।

> [!note] Notes and Highlights
> [Spinoza's Ethics by George Elliot](../Notes%20and%20Highlights/Spinoza_s%20Ethics%20by%20George%20Elliot)

> [!info] About Spinoza's Ethics by Benedictus de Spinoza
><img src="https://books.google.com/books/content?id=LVOjDwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api" style="float: left; margin-right: 1em;width: 150px; height: auto;" /> "This is a scholarly edition of Eliot's translation of Spinoza's Ethics, which today reads as a fresh, elegant and faithful rendering of the original Latin text. The editor's notes on the text will indicate Eliot's amendments to her manuscript, and discuss those translation decisions which differ from the standard modern English editions, and have a bearing on interpretive and philosophical issues. Eliot's translation of the Ethics is prefaced by an editorial essay which briefly introduces Spinoza's text in its 17th-century context and outlines its key philosophical claims, before discussing Eliot's interest in Spinoza, the circumstances of her translation of the Ethics, and the influence of Spinoza's ideas on her literary work. It presents Eliot's reading of Spinoza in the broader context of the 19th-century reception of his philosophy by Romantic writers, while tracing the distinctive ways in which Eliot drew on Spinoza's radical views on religion, ethics, and human psychology"

[^1]: [Part I: Of God](Spinoza_s%20Ethics%20by%20George%20Elliot#Part%20I:%20Of%20God)
[^2]: [Spinoza on God's scope of action](../Notes%20and%20Highlights/Spinoza_s%20Ethics%20by%20George%20Elliot#^7f62f8)