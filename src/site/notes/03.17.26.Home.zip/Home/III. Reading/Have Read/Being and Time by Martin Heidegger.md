---
{"title":"Being and Time","created":"2026-03-16T18:10:07.956-10:00","updated":"2026-03-17T14:14:06.904-10:00","read_count":"1","authors":["Martin Heidegger","Joan Stambaugh","Dennis J. Schmidt"],"isbn10":1438432763,"log":[{"status":"Read","timestamp":"2021-05-01T00:00:00+06:00"},{"status":"To Read","timestamp":"2019-10-03T00:00:00+06:00"}],"reviewed":true,"rating":3,"dg-publish":true,"dg-note-icon":2,"cover":"https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1298438455i/92307.jpg","dg-metatags":"https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1298438455i/92307.jpg","tags":["existentialism","ontology","philosophy","Reading","haveread"],"status":"Read","reading_notes":"[Being and Time by Martin Heidegger](Home/III.%20Reading/Notes%20and%20Highlights/Being%20and%20Time%20by%20Martin%20Heidegger)","dg-path":"III. Reading/Have Read/Being and Time by Martin Heidegger","permalink":"/iii/","metatags":"https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1298438455i/92307.jpg","dgPassFrontmatter":true,"noteIcon":2}
---






> [!warning]
> Before we proceed, a perhaps typical reminder: **I have not understood a lot/most/anything of this book.**

I have a very mixed feeling regarding this book.

Heidegger wanted to answer the question of all questions, the question of our being. He stopped halfway (the second part of the book has never been published). However, the first part is thought-provoking enough for generations of philosophers.

A personal takeaway of mine from this unfinished magnum opus is the approach of expressing a body of interconnected content pretty coherently is immensely difficult. Nowadays, I often find myself silent in the fear that there is too much to explain.

Here go the things that bothered me…

In existential philosophy, the point of departure is to be expected from existence, not some idealized essence. Heidegger was existential all the way. He was sound in his argument. However, even being a person of modern era, he is plagued by the same tendency of disregarding natural science like most other philosophers. Metaphysics must not deny the findings of much rigorous observations of modern [Physics](charleshoots.net/II.%20Teaching/Physics) . We cannot redefine time (at least not usefully) without taking [[charleshoots.net/IV. Journal/Health/Note\|Note]] of what [Physics](charleshoots.net/II.%20Teaching/Physics) says of the time.

The same goes for the Dasein. Dasein, the conscious being is modelled after only conscious beings we know, that is, Human. I think it is important to consult biology in this regard if we want anything verifiable at all.

Both of these two issues, of course, stems from the tendency of not bothering with proof common amongst philosophers.

> [
<div class="transclusion internal-embed is-loaded"><div class="markdown-embed">




# Note


</div></div>
] Notes and Highlights
> [Being and Time by Martin Heidegger](../Notes%20and%20Highlights/Being%20and%20Time%20by%20Martin%20Heidegger)

> [!info] About Being and Time by Martin Heidegger
> <img src="https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1298438455i/92307.jpg" style="float: left; width: 150px; height: auto; margin-right: 1em;" /> One of the most important philosophical works of our time, a work that has had tremendous influence on philosophy, literature, and psychology, and has literally changed the intellectual map of the modern world.
