---
{"title":"The Water Dancer","created":"2026-03-16T18:10:07.960-10:00","updated":"2026-03-17T14:14:07.241-10:00","read_count":"1","authors":["Ta-Nehisi Coates"],"rating":5,"reviewed":true,"tags":["bestreads","african","america","Reading","haveread"],"log":[{"status":"Read","timestamp":"2020-05-24T00:00:00+06:00"},{"status":"To Read","timestamp":"2019-11-19T00:00:00+06:00"}],"status":"Read","dg-publish":true,"dg-note-icon":3,"cover":"https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1549993860i/43982054.jpg","dg-path":"III. Reading/Have Read/The Water Dancer by Ta-Nehisi Coates","permalink":"/iii/","dgPassFrontmatter":true,"noteIcon":3}
---






My direct exposure to the slavery that has been suffered by Africans naturally is none. Even cultural exposure is a remote thing, only through books and movies. The first book I read about slavery is the classic *Uncle Tom's Cabin*. Now, *Uncle Tom's Cabin* follows mostly the journey of Uncle Tom and gives us quite a picture of how cruel slavery is. It is focused and intense. To understand the landscape of centuries of slavery, it is not quite enough. Then came some movies and other books. Only after reading Howard Zinn’s *[A People’s History of the United States](Home/III.%20Reading/Have%20Read/A%20People_s%20History%20of%20the%20United%20States%20by%20Howard%20Zinn)* I got a grasp of the big picture of slavery in the United States. I read some of Du Bois, and last summer, I read my first Ta-Nehisi Coates, *Between the World and Me*.

Now, *[Between the World and Me](Between%20the%20World%20and%20Me%20by%20Ta-Nehisi%20Coates)* is a book of a whole other level. The time is of our own, slavery has vanished, but the trauma, distrust and violence didn't. Coates, in a monologue to his son, in the form of a letter expressed the African-American life which I believe no one had done with this much psychological insight.

Naturally, I started reading this book with high expectations. Of course, this book is not as good as the aforementioned one by Coates, but it is a good book. Coates blended a pre-civil war America, the race-wide trauma and melancholy, suffering, faith and redemption and magic realism coherently. Characters are dynamic, details are adequate, and many smaller stories intertwined to tell a bigger story, a story of love, parting, longing, pain and most of all 'remembrance'. Enjoyed the book.

A considerable amount of time is spent in this book on some sort of magic, a means of salvation, prophetic in characteristic. However, I always felt that this magic is just a small detail. The more important part is what triggers this magic, i.e. memory. To be specific, the memory of suffering. Now, what I find amazing is this emphasis on memory, remembering is a common thing in the whole African-American community. **Cudjo Lewis** (in *[Barracoon: The Story of the Last Slave](Home/III.%20Reading/Have%20Read/Barracoon%20by%20Zora%20Neale%20Hurston)*) never forgot Africa, he carried Africa within him, neither did Du Bois, nor the faithful coloured Christians, who sang church songs, for generations, in the melody of their long lost motherland. The same communal memory, also allowed the water dancers to do the magic, making them powerful and prophetic.

Next comes, I think, *The Underground*, an organization where people of all colours and races are trying to free as many slaves as they can. This gave the context to tell more stories and expound on ideas like freedom, revolution, radicalism and all.

I finished the book on a sleepless night. The melancholy seeped into me, and when I finished it, it was no 'happily ever after', but a mix of many things, especially with a dualism of pragmatism and emotion.
