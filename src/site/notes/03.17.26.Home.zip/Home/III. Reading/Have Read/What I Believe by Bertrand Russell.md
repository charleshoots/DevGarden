---
{"title":"What I Believe","created":"2026-02-04T07:22:02.000-10:00","updated":"2026-02-07T23:58:17.925-10:00","read_count":"1","authors":["Bertrand Russell"],"isbn10":"0415325099","isbn13":"9780415325097","rating":5,"dg-publish":true,"cover":"https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1356456172i/67354.jpg","dg-metatags":{"og:image":"https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1356456172i/67354.jpg"},"tags":["law","philosophy","science","sociology","morality"],"log":[{"status":"Read","timestamp":"2022-10-27T00:00:00+06:00"},{"status":"To Read","timestamp":"2020-07-12T00:00:00+06:00"}],"status":"Read","reading_notes":"[What I Believe](What%20I%20Believe)","dg-path":"III. Reading/Have Read/What I Believe by Bertrand Russell","permalink":"/iii-reading/have-read/what-i-believe-by-bertrand-russell/","metatags":{"og:image":"https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1356456172i/67354.jpg"},"dgPassFrontmatter":true,"noteIcon":"1"}
---



> [!note] Notes and Highlights
> [What I Believe](../Notes%20and%20Highlights/What%20I%20Believe)

> [!info] About What I Believe by Bertrand Russell
><img src="https://books.google.com/books/content?id=NrLPSgtYepwC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api" style="float: left; margin-right: 1em;width: 150px; height: auto;" /> Along with Why I Am Not a Christian, this essay must rank as the most articulate example of Russell's famed atheism. It is also one of the most notorious. Used as evidence in a 1940 court case in which Russell was declared unfit to teach college-level philosophy, What I Believe was to become one of his most defining works. The ideas contained within were and are controversial, contentious and - to the religious - downright blasphemous. A remarkable work, it remains the best concise introduction to Russell's thought.