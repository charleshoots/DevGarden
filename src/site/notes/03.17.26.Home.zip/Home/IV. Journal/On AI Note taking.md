---
{"title":"On AI Note-taking","aliases":["On AI Note-taking"],"location":"Badda, Dhaka","tags":["ai","note-taking"],"created":"2026-02-08T19:47:42.000-10:00","updated":"2026-03-17T14:40:48.275-10:00","dg-publish":true,"dg-note-icon":2,"dg-path":"IV. Journal/On AI Note-taking","permalink":"/iv-journal/on-ai-note-taking/","dgPassFrontmatter":true,"noteIcon":2}
---



Much of the early AI research (and contemporary ones, to an extent) revolved around using content and actions working on that content interchangeably. That is why languages like LISP gained so much popularity in AI programming.

It means that content may contain kernels of actions and actions can be described in the language of content. It also means that nouns can be verbs in stasis.

Nowadays, whenever I visit relevant communities on Reddit (Obsidian for example), I encounter numerous LLM-powered workflows every day. They will transcribe and/or summarise the contents of various formats, and save them for you in your [[charleshoots.net/IV. Journal/Health/Note\|Note]]-taking app.

Ironically these AI [[charleshoots.net/IV. Journal/Health/Note\|Note]]-taking workflows robbed the essence of [[charleshoots.net/IV. Journal/Health/Note\|Note]]-taking itself.

What is a [[charleshoots.net/IV. Journal/Health/Note\|Note]]? Is it a piece of text? How is it different from a book, a thesis paper, or a poem? A [[charleshoots.net/IV. Journal/Health/Note\|Note]], now a piece of *content*, contains the momentum of its action: **taking [[charleshoots.net/IV. Journal/Health/Note\|Note]]**. And taking [[charleshoots.net/IV. Journal/Health/Note\|Note]] is a process. It is not merely transcribing or summarising. It is a cerebral process where something grabs our attention, and *we* consider it important based on *our experience*. An AI can summarise something better than I, or transcribe something more accurately, but it can never take my notes for me. Just like it can never eat for me.

So, through these workflows all we are collecting are snippets of blurbs we have no connection with. It is just hoarding— of fool's gold.