---
{"weather":"unknown","mood":"indifferent","title":"About Programming","updated":"2026-03-17T14:14:07.727-10:00","tags":["passion","philosophy","programming","journal"],"dg-publish":true,"dg-note-icon":"withered","created":"2026-03-16T18:10:07.968-10:00","dg-path":"IV. Journal/About Programming","permalink":"/iv/","dgPassFrontmatter":true,"noteIcon":"withered"}
---






Among the two passions I have, programming is the one I'm less passionate about. But, it's a passion still and, since it is the work that bring me money, I spend a considerable amount of time with it. After all, we seldom can create a job out of our passion in this unforgiving, ever-expecting monster of a society.

When I started, it was purely a passion. Never thought that it will be a profession for me. But, professionalism has little to do with profession. It's an attitude to do things in the best way possible.

> [!fail] Outdated
> The following two paragraphs contain an outdated view regarding the power of infotech. My opinion regarding this has been expressed [here](On%20Career#^a97315).

Another thing I would like to point out that a passion is a spiritual journey to me. It requires one's utmost attention and intelligence. You'll indeed find a philosophical vibe around programming (Read **[Structure and Interpretation of Computer Programs](..III.%20Reading/Need%20To%20Read/Structure%20and%20Interpretation%20of%20Computer%20Programs%20by%20Harold%20Abelson)**), which is only too natural. You'll find this in design and manuals of UNIX and friends, in programming paradigms and software architecture and also in individual's codes where they try to write code in the best possible way. It manipulated data in so many ways and yet exploring many more that it is now possible to establish a new religion on it, Data Religion.

In these days, *Code is law*,[^1] peoples are dreaming about a totally distributed internet where the freedom of expression will be deeply integrated and, all of these are possible because of a long journey through programming to a better Information philosophy.
{ #868fa6}


When I write code, particularly open-source libraries, I feel myself contributing to the next big picture of the internet. Indeed, it is not only a spiritual journey to my own self, but also a philosophical journey to the next society.

[^1]: [Code is Law: On liberty in cyberspace](https://harvardmagazine.com/2000/01/code-is-law-html) is an article by Lawrence Lessig where he argues that 'code' will be the next big thing to regulate and law enforcement.