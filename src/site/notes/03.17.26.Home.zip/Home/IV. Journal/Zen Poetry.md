---
{"title":"Zen Poetry","updated":"2026-03-17T14:14:07.887-10:00","dg-note-icon":3,"tags":["poetry","literature","buddhism","zen","journal"],"created":"2026-03-16T18:10:07.969-10:00","dg-publish":true,"dg-path":"IV. Journal/Zen Poetry","permalink":"/iv/","dgPassFrontmatter":true,"noteIcon":3}
---






Art essentially is a matter of attachment. An attachment that connects one to the very depth of the world.[^1] Zen, on the other hand, is a practice of detachment. When they met in the atmosphere of Asian aesthetics, they have created a genre with blends of various flavours. Exploring Zen poetry is like taking a journey through your existential crisis.
{ #859d9d}


It can be deduced naturally that the poets of Zen (often priests) walked on a thin line. Their attachment was not of the mundane kind that we know. Artists, in general, are subtly attached to reality with a kind of super-sensibility, a refined type of attachment.

Precisely for the practice of Zen where the goal is to get enlightenment with a true description of reality and cultured detachment, Zen poets scrutinized their attachment within the framework of Buddhism. This scrutiny yielded surprising results in terms of art.

When Ikkyū Sōjun, the eccentric priest, poet, and lover writes:


<div class="transclusion internal-embed is-loaded"><a class="markdown-embed-link" href="Reading/notes-and-highlights/the-poetry-of-zen-by-sam-hamill-j-p-seaton/#e34d1e" aria-label="Open link"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="svg-icon lucide-link"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path></svg></a><div class="markdown-embed">



LIKE vanishing dew,
a passing apparition
or the sudden flash
of lightning—already gone—
thus should one regard one’s self. 

</div></div>


or


<div class="transclusion internal-embed is-loaded"><a class="markdown-embed-link" href="Reading/notes-and-highlights/the-poetry-of-zen-by-sam-hamill-j-p-seaton/#605009" aria-label="Open link"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="svg-icon lucide-link"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path></svg></a><div class="markdown-embed">



AND what is mind
and how is it recognized?
It is clearly drawn
in sumi ink, the sound
of breezes drifting through pine. 

</div></div>


He is writing about Zen. These [Tanka](https://en.wikipedia.org/wiki/Tanka) poems are not only poems, but [koans](https://en.wikipedia.org/wiki/Koan) too. A central idea of Buddhism is [Anattā](../Entities/Concept/Buddhism/Anatman), which is the denial of the existence of self or soul as an indivisible and indestructible unit. Instead, the self we know is a continuous process working through our senses. It is very much material and the self is considered as an illusion.

Therefore, the self, understood through Zen, is superbly temporal like a drop of dew or a flash of lightning. It is as elusive as sound painted in ink.

The teaching of Zen, ironically, can produce the opposite of detachment. For example, Saigyō writes:


<div class="transclusion internal-embed is-loaded"><a class="markdown-embed-link" href="Reading/notes-and-highlights/the-poetry-of-zen-by-sam-hamill-j-p-seaton/#1c8b2a" aria-label="Open link"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="svg-icon lucide-link"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path></svg></a><div class="markdown-embed">



I’D like to divide
myself in order to see,
among these mountains,
each and every flower
of every cherry tree 

</div></div>


Now, this is a very special kind of urge to be attached. It is also a kind of self-denial but an acceptance of nature and the overwhelming ecstasy it holds for us. This attitude, this detachment through attachment, is a recurring theme for many poems. An anonymous Japanese poet writes:


<div class="transclusion internal-embed is-loaded"><a class="markdown-embed-link" href="Reading/notes-and-highlights/the-poetry-of-zen-by-sam-hamill-j-p-seaton/#c91c44" aria-label="Open link"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="svg-icon lucide-link"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path></svg></a><div class="markdown-embed">



TO learn how to die,
watch cherry blossoms, observe
chrysanthemums. 

</div></div>


Poetry like this requires a certain emotional quality known as '[Mono no aware](../Entities/Concept/Aesthetics/Mono%20no%20aware)' which is often translated as 'Love for Impermanence' or 'Pathos of Things'. [Impermanence](../Entities/Concept/Buddhism/Anitya) is a core idea of Buddhism. This supplied Zen poets with a framework to nurture their mono no aware.

Then comes the anguish. Even with a solid understanding of Zen philosophy, poets often faced situations that caused them pain beyond reason. For [Bashō](../Entities/Person/Matsuo%20Bashō), it was when his older brother presented him a lock of white hair of their late mother:


<div class="transclusion internal-embed is-loaded"><a class="markdown-embed-link" href="Reading/notes-and-highlights/narrow-road-to-the-interior-and-other-writings/#974afb" aria-label="Open link"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="svg-icon lucide-link"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path></svg></a><div class="markdown-embed">



If I took it in hand,  
it would melt in my hot tears—  
heavy autumn frost

</div></div>


Or, for Kobayashi Issa, it was the death of his baby girl and the crying of his wife. Zen was there, was the impermanence too, so was the anguish:


<div class="transclusion internal-embed is-loaded"><a class="markdown-embed-link" href="Reading/notes-and-highlights/the-poetry-of-zen-by-sam-hamill-j-p-seaton/#17ca5d" aria-label="Open link"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="svg-icon lucide-link"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path></svg></a><div class="markdown-embed">



This world of dew
is only the world of dew—
and yet … and yet … 

</div></div>


#### References
  1. [The Poetry of Zen by Sam Hamill, J.P. Seaton](..III.%20Reading/Have%20Read/The%20Poetry%20of%20Zen%20by%20Sam%20Hamill)
  2. [Narrow Road to the Interior and Other Writings by Matsuo Bashō](..III.%20Reading/Have%20Read/Narrow%20Road%20to%20the%20Interior_%20And%20Other%20Writings%20by%20Matsuo%20Bashō)

[^1]: [[IV. Journal/শিল্পভাবনা ১ হৃদয়বৃত্তি#^715f40\|শিল্পভাবনা ১ হৃদয়বৃত্তি]]