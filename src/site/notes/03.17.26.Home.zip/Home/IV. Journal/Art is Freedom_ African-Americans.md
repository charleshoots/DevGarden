---
{"title":"Art is Freedom: African-Americans","aliases":["Art is Freedom: African-Americans"],"location":"Badda, Dhaka","tags":["music","negroid","culture","african","american","journal"],"created":"2026-03-16T18:10:07.968-10:00","updated":"2026-03-17T14:14:07.744-10:00","dg-publish":true,"dg-note-icon":2,"dg-path":"IV. Journal/Art is Freedom_ African-Americans","permalink":"/iv/","dgPassFrontmatter":true,"noteIcon":2}
---







<div class="transclusion internal-embed is-loaded"><a class="markdown-embed-link" href="Reading/notes-and-highlights/treat-it-gentle-by-sidney-bechet/#d38c7f" aria-label="Open link"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="svg-icon lucide-link"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path></svg></a><div class="markdown-embed">



But if you have a feeling for the music, you can understand him, and that's why he keeps it so important to himself. And he's always been trying. The black man, he's been learning his way from the beginning. A way of saying something from inside himself, as far back as time, as far back as Africa, in the jungle, and the way the drums talked across the jungle, the way they filled the whole air with a sound like the blood beating inside himself. 

</div></div>


When the black cargoes landed, and slaves walked out all they had was music.

Music, that eased their torment in tobacco and cotton fields.

They learned about Christianity, in the [invisible churches](https://en.m.wikipedia.org/wiki/Invisible_churches), and eventually in black churches shunned by the white Christians they found their solace in music.

Then came the Ragtime, Blues, and Jazz— sharing the African root and pathos.

It was music all along. Music is African-American's one true spirituality.