---
{"weather":"unknown","mood":"indifferent","title":"Art and Error","updated":"2026-03-17T14:14:07.734-10:00","tags":["art","philosophy","journal"],"dg-publish":true,"created":"2026-03-16T18:10:07.968-10:00","dg-path":"IV. Journal/Art and Error","permalink":"/iv/","dgPassFrontmatter":true,"noteIcon":"1"}
---






> And then there are painters who never do anything that is no good, who cannot do anything bad, just as there are ordinary people who can do nothing but good. — Vincent Van Gogh

বেশি ভালো যে ভালো না, বরং তার ভীড়ে ভালো হয়ে যায় মাঝারি সে কথা রবীন্দ্রনাথও জানিয়ে দিয়েছেন অমিত-র মুখ দিয়ে। [[The Starry Night সেকাল-একাল\|সারাজীবন ভুল করে যাওয়া মানুষগুলোই]] কিছুতেই একটা পথে বা মতে নিজেকে মানিয়ে নিতে পারে না। পারে না বলেই হয়ত দেখতে পায়, বলতে পারে অনেককিছু। ফর্ম ভাঙলে তবে আর্ট মডার্ন হয়। গদ্যের কাঠিন্য পেলে কবিতা হয় সুপুরুষ। দুজনের গান্ধারের ঊনিশ-বিশে গায়কী হয়ে গেলো আলাদা।