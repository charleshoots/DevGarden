---
{"id":"A Ghost Story","aliases":["A Ghost Story"],"tags":["politics","journal"],"created":"2026-03-16T18:10:07.967-10:00","dg-note-icon":3,"dg-publish":true,"location":"Badda, Dhaka","title":"A Ghost Story","updated":"2026-03-17T14:14:07.710-10:00","dg-path":"IV. Journal/A Ghost Story","permalink":"/iv/","dgPassFrontmatter":true,"noteIcon":3}
---






Ghosts are people— untimely demised with urges intact.

As a modern man, you don't believe ghosts exist, do you?

Of course, they are real! I can prove that to you. On a summer afternoon in Dhaka carefully notice the Rickshaw-Pullers. Illusive they are with sweats and breaths, and a bodily existence, they are indeed ghosts. If you observe, you will find their muscles are composed of thin but tenacious dolour. Notice the fiery eyes, vivid, yet empty of essence. Notice how they pull their rickshaws, like clockwork, with some sort of supernatural strength as if space is elastic and time doesn't move for them. Take [[charleshoots.net/IV. Journal/Health/Note\|Note]] of their faces, devoid of expression, devoid of meaning, rhythm, or reason. They were robbed of their bare necessities, dignity, and even a life worth living, a meaning that doesn't depend solely on other's profit— what remains but a ghost?

Often I feel the urge to call Bhoot FM[^1] and say, "You won't believe Russell bhai! Today, when I was coming back from office, my rickshaw-wala was a ghost, and so was the one who was overtaking us…"

The subtlest ghosts, with the most ephemeral differences from us, however, can be found only if we look into a mirror. Under our skin, I cannot ignore me eroding every day, with every vote I couldn't make, every scheme by syndicates, every draconian punishment on us to keep us mum, to give away our last one free inch, our integrity. I cannot ignore my gradual disenfranchisement robbing me of any social meaning a human has. I find myself a ghost, with all the urges intact, but not human anymore.

[^1]: A radio program which was discontinued long ago.
