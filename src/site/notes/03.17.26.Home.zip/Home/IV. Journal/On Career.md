---
{"weather":"unknown","mood":"indifferent","title":"On Career","updated":"2026-03-17T14:14:07.894-10:00","latitude":23.784735,"longitude":90.41618167,"altitude":-44.4,"dg-publish":true,"dg-note-icon":2,"tags":["life","work","programming","journal"],"location":"Badda, Dhaka","created":"2026-03-16T18:10:07.969-10:00","dg-path":"IV. Journal/On Career","permalink":"/iv/","dgPassFrontmatter":true,"noteIcon":2}
---






An introspection of my life cannot be possibly done without a retrospection, a walk down the aisles between desks.

The profession is not something strictly financial for me. A person can be a professional without making a cent from what is being professionally done by the said one. Anyway, I made plenty of money from my primary profession, which is programming. My secondary profession is writing, which I take very seriously. I never wrote anything of much value, though.

Programming appealed to my **deep** urge of making sense, itemizing and organizing, and making a system of things. The emphasis on 'deep' asks for an explanation. It is deep because superficially I am disorganization incarnated. I live in a state of a complete mess. Yes, I do go to the office well-dressed, but that is a mindless thing I just practiced. I don't care about how I look.

However, I like to organize my thoughts. I want to make connections about everything I perceive. The problem is, I know too little. In fact, we know too little. My deep urge to find the theory of everything has been and is being thwarted by nature from time immemorial.

Programming, along with programming languages, can be considered an applied branch of logic. A dream comes true situation for Bertrand Russell. Probably, Alan Turing was well aware of works of Russell's domain.

Passion for programming remains strong after all these years. However, I no longer think it as powerful as I thought [before](About%20Programming#^868fa6). In fact, I believe, it shouldn't be granted that much power over our life. [Rules embedded in the system is not a sufficient answer to the moral problems](../..III.%20Reading/Notes%20and%20Highlights/What%20I%20Believe#^433c21).
{ #a97315}
