---
{"tags":["journal","travel"],"custom-width":49,"dg-publish":true,"dg-path":"IV. Journal/Living in the PNW/Moving from Hawaii","permalink":"/iv/","dgPassFrontmatter":true,"noteIcon":"1","created":"2026-03-16T18:10:07.969-10:00","updated":"2026-03-17T14:14:07.794-10:00"}
---






| Table | 1   | 2   |
| ----- | --- | --- |
| a     |     |     |

