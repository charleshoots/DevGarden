---
{"tags":["Index"],"custom-width":49,"dg-publish":true,"dg-path":"IV. Journal/Living in the PNW/Living in the PNW","permalink":"/iv/","dgPassFrontmatter":true,"noteIcon":"1","created":"2026-03-16T18:10:07.968-10:00","updated":"2026-03-17T17:27:15.719-10:00"}
---



[[Home/Home\|Home]] 
[[Home/IV. Journal/IV. Journal\|IV. Journal]]

---

 [[Home/IV. Journal/Living in the PNW/Geologist in the PNW\|Geologist in the PNW]]
 [[Home/IV. Journal/Living in the PNW/Hiking\|Hiking]]
 [[Home/IV. Journal/Living in the PNW/Moving from Hawaii\|Moving from Hawaii]]
 [[Home/IV. Journal/Living in the PNW/Teaching in the PNW\|Teaching in the PNW]]


---
