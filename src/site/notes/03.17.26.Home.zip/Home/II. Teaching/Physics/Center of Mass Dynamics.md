---
{"dg-publish":true,"dg-path":"II. Teaching/Physics/Center of Mass Dynamics","permalink":"/ii-teaching/physics/center-of-mass-dynamics/","dgPassFrontmatter":true,"noteIcon":"1","created":"1984-01-23T22:00:00.000-10:00","updated":"2026-03-17T15:04:06.743-10:00"}
---


> [!summary]
The center of mass in terms of dynamics describes the force the center of mass will feel and its effect on motion.
> 
**Key Equations:**
$F_{ext}=a_{cm}M$

>[!info]+ Read Time
**⏱ 1 min**

# Definition 
The center of mass in terms of dynamics describes the [[Home/II. Teaching/Physics/External & Internal Forces\|external forces]] as if all the mass were centred on a point. This describes the motion of the center of mass using [[Home/II. Teaching/Physics/Newton Laws\|Newton's laws]].

## Derivation 
> [!warning] Assumptions
To derive an equation to describe the external forces on the center of mass, assume the following:
> - The [[Home/II. Teaching/Physics/Center of Mass Velocity & Momentum\|velocity center of a mass]] in terms of [[Home/II. Teaching/Physics/Linear Momentum\|momentum]] is $v_{cm} = \frac{p_{tot}}{M}\Rightarrow p_{tot}=v_{cm}M$
> - The [[Derivative\|derivative]] of [[Velocity\|velocity]] is [[Acceleration\|acceleration]]
> - The [[Derivative\|derivative]] of [[Home/II. Teaching/Physics/Linear Momentum\|momentum]] is the [[Home/II. Teaching/Physics/Newton Laws\|external force]]

$$
\begin{array}{c}
\frac{d}{dt} \left[ p_{tot}= v_{cm}M \right]  \\
\frac{dp}{dt}=\frac{dv}{dt}M \\
F_{ext}=a_{cm}M
\end{array}
$$

# Resources
<iframe width="560" height="315" src="https://www.youtube.com/embed/aIhScO3_I50?si=LBr7KTZt4r_Ge5_R&amp;start=2118" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>