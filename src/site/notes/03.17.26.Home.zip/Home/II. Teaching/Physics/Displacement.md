---
{"dg-publish":true,"tags":["teaching","physics","kinematics"],"permalink":"/ii/","dgPassFrontmatter":true,"noteIcon":"1","created":"1984-01-23T22:00:00.000-10:00","updated":"2026-03-17T14:14:02.250-10:00","dg-path":"II. Teaching/Physics/Kinematics/Displacement"}
---





> [!summary]
Displacement describes an object's motion over an interval
> 
**Key Equations:**
> 
Displacement:
$\Delta x = x(t_{2})-x(t_{1})$

>[!info]+ Read Time
**⏱ 1 min**

# Definition
Displacement describes an object's motion over an interval. It's a vector quantity and can be positive or negative. Mathematically, displacement is described as a function $x(t)$ or described as the change over an interval

$$
\begin{array}{c}
\text{Displacment (1D)} = x(t_{2})-x(t_{1}) \\
 \\
\text{Or as a form as velocity:} \\
\vec{d} = \int_{a}^b \vec{v(t)}dt
\end{array}
$$

# Resources
<iframe width="560" height="315" src="https://www.youtube.com/embed/w_A_WHXWMU8?si=J-_xmWbrM80kYgfd&amp;start=683" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>


---
<!-- Light Mode Newsletter Embed -->
<div class="mm-form-light">
  <iframe
    src="https://updates.cyberleadhub.com/widget/form/Y0kpQVpjJQuxEfX59m17"
    id="inline-Y0kpQVpjJQuxEfX59m17"
    title="Join Math & Matter Newsletter (Light)"
    data-height="900"
    scrolling="no"
    allowtransparency="true"
    loading="lazy"
    style="width:100%;height:350px;border:none;border-radius:10px;background:transparent;overflow:hidden"
  ></iframe>
</div>

<!-- Dark Mode Newsletter Embed -->
<div class="mm-form-dark">
  <iframe
    src="https://updates.cyberleadhub.com/widget/form/lbeDLm24VjuaFxhjccA1"
    id="inline-lbeDLm24VjuaFxhjccA1"
    title="Join Math & Matter Newsletter (Dark)"
    data-height="900"
    scrolling="no"
    allowtransparency="true"
    loading="lazy"
    style="width:100%;height:350px;border:none;border-radius:10px;background:transparent;overflow:hidden"
  ></iframe>
</div>

<!-- Provider script (only once) -->
<script src="https://updates.cyberleadhub.com/js/form_embed.js"></script>
