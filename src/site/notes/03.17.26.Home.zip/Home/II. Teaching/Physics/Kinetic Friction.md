---
{"dg-publish":true,"dg-path":"II. Teaching/Physics/Kinetic Friction","permalink":"/ii-teaching/physics/kinetic-friction/","dgPassFrontmatter":true,"noteIcon":"1","created":"1984-01-23T22:00:00.000-10:00","updated":"2026-03-17T15:04:06.702-10:00"}
---


> [!summary]
Kinetic friction is friction created when an object is in motion. 
> 
**Key Equations:**
.
Coefficient inequality 
$\mu_{k}<\mu_{s}$
> 
Kinetic friction
$f_{s}=\mu_{k}|\vec{N}|$

>[!info]+ Read Time
**⏱ 1 min**

# Definition
Kinetic friction is the friction that occurs when an object is in motion. This type of friction is usually of the stays the same in magnitude and opposes motion. The coefficient of kinetic friction is denoted as $\mu _k$. 

Kinetic friction can be described in two main ways. The kinetic friction is equal to the coefficient of kinetic friction times the magnitude of the normal force. As well, the coefficient of kinetic friction is greater than the coefficient of [[Home/II. Teaching/Physics/Static Friction\|static friction]].

$$
\begin{array}{c}
f_{k}= \mu_{k} |\vec{N}|  \\
\mu_{k} < \mu _s
\end{array}
$$

> [!note]+ Kinetic Friction Diagram
![[kf_1.png\|kf_1.png]]
[^1]
A person pushes a box, with a force in the $x$ direction. The force overpowers the friction, creating acceleration in the $x$ direction.

