---
{"dg-publish":true,"dg-path":"II. Teaching/Physics/Angular Speed","permalink":"/ii-teaching/physics/angular-speed/","dgPassFrontmatter":true,"noteIcon":"1","created":"1984-01-23T22:00:00.000-10:00","updated":"2026-03-17T15:04:06.957-10:00"}
---


> [!summary]
Angular speed describes how fast an object is rotating around a circle
> 
**Key Equations:**
> 
Angular speed:
$\omega = \frac{d\theta}{dt}$
> 
If the angular speed is constant:
$\omega= \frac{2\pi r}{T}$

>[!info]+ Read Time
**⏱ 1 min**

# Definition 
Angular speed is a [[Scalar & Vectors\|scalar quantity]] and tells you how fast you are rotating around a circle. Mathematically, this is the [[Instantaneous\|instantaneous change]] of [[Home/II. Teaching/Physics/Angular Displacement\|angular displacement]]

$$
\omega = \frac{d\theta}{dt}
$$

> [!note] If angular speed is always constant
If angular speed is always constant around a circle, then the angular speed can also be described as the time it takes to loop around a circle with circumference $2\pi r$ or 
> 
> $$
\omega = \frac{2\pi r}{T}
> $$


---

> 📚 Like this note? [Star the GitHub repo](https://github.com/rajeevphysics/Obsidian-MathMatter) to support the project and help others discover it!

---
