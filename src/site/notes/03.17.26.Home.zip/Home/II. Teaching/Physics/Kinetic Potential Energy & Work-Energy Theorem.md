---
{"dg-publish":true,"tags":["teaching","physics","energywork"],"permalink":"/ii/","dgPassFrontmatter":true,"noteIcon":"1","created":"1984-01-23T22:00:00.000-10:00","updated":"2026-03-17T14:14:02.231-10:00","dg-path":"II. Teaching/Physics/Energy & Work/Kinetic Potential Energy & Work-Energy Theorem"}
---






> [!summary]
Kinetic energy is the amount of energy an object has because it's moving
> 
**Key Equations:**
> 
Kinetic energy:
$K = \frac{1}{2}mv^2$
> 
Work-Energy Theorem:
$W=\Delta K$ / $W = \Delta E$

>[!info]+ Read Time
**⏱ 1 min**

# Definiton
Kinetic energy is how much energy an object has because it is moving. It's the [work](Work) done on an object to give it or keep it in motion 

## Derivation (Work-Energy Theorem)
> [!warning] Assumptions
To derive an equation to describe the energy when a force gives an object motion, assume the following:
> - [Work](Work) is general is $W = \int_{x_{i}}^{x_{f}} \vec{F} \cdot \vec{dx}$
> - The [force](../Dynamics/Forces) is always constant
> - Force is described as $F=ma$
> - The object has mass $m$
> - From [kinematics](../Kinematics/Kinematics) $ax = \frac{1}{2}(v^2 - v_0
{ #2}
)$

$$\begin{array}{c}  
W = \int_{x_{i}}^{x_{f}} \vec{F} \cdot \vec{dx}\\
W = F\Delta x \\ 
W = ma\Delta x \\ 
W = \frac{1}{2}m (v^2 - v_0
{ #2}
) \\  \\
\text{So the kinetic energy can be described as:} \\
\Delta K = \frac{1}{2}m (v^2 - v_0
{ #2}
)  \\ \\

\text{Then we make the defintion of a work-energy theorem:} \\

W = \Delta K \\

\end{array}$$

> [!note]
$W =\Delta K$ is valid for any type of energy $W = \Delta E$


---

> ✍️ This project’s been a labour of love.  
> If it helped, [give Math & Matter a star](https://github.com/rajeevphysics/Obsidian-MathMatter) and let me know what you'd like to see next.

---
