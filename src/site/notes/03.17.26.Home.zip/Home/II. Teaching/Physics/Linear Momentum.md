---
{"dg-publish":true,"dg-path":"II. Teaching/Physics/Linear Momentum","permalink":"/ii-teaching/physics/linear-momentum/","dgPassFrontmatter":true,"noteIcon":"1","created":"1984-01-23T22:00:00.000-10:00","updated":"2026-03-17T15:04:06.713-10:00"}
---


>[!summary]
Linear momentum describes how much force affects motion
Impulse is the change in linear momentum over time
>
Linear momentum is an intrinsic property
>
**Key equations:**
> 
Momentum:
$p = mv$

>[!info]+ Read Time
**⏱ 2 mins**

# General Principle
Linear momentum is a conserved quantity and describes how much force affects motion. It's an [[Intrinsic & Extrinsic Properties\|intrinsic]] property. Mathematically, linear momentum is defined as the mass times [[Velocity\|velocity]] at a point in time.

$$
\vec{p} =m\vec{v}
$$

>[!info] Important 
High momentum - Harder to stop
Low momentum - easier to stop


---

> ✍️ This project’s been a labour of love.  
> If it helped, [give Math & Matter a star](https://github.com/rajeevphysics/Obsidian-MathMatter) and let me know what you'd like to see next.

---
