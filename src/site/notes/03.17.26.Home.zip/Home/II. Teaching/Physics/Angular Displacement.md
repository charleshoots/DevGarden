---
{"dg-publish":true,"dg-path":"II. Teaching/Physics/Angular Displacement","permalink":"/ii-teaching/physics/angular-displacement/","dgPassFrontmatter":true,"noteIcon":"1","created":"1984-01-23T22:00:00.000-10:00","updated":"2026-03-17T15:04:06.836-10:00"}
---


> [!summary]
Angular displacement describes the displacement covered while going around a circle
> 
**Key Equations:**
$\theta = \frac{s}{r}$

>[!info]+ Read Time
**⏱ 1 min**

# Definition 
Angular displacement describes the [[Home/II. Teaching/Physics/Displacement\|displacement]] covered by rotating around a circle. Mathematically, this is described as the [[Arc Length of Circles\|arc length]] divided by the radius of the circle.

$$
\theta = \frac{s}{r}
$$

# Resources
<iframe width="560" height="315" src="https://www.youtube.com/embed/V9lbH_LkCio?si=n88J7ZilHZF6_siM" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>


---

> 📚 Like this note? [Star the GitHub repo](https://github.com/rajeevphysics/Obsidian-MathMatter) to support the project and help others discover it!

---
