---
{"dg-publish":true,"tags":["teaching","physics","kinematics"],"permalink":"/ii/","dgPassFrontmatter":true,"noteIcon":"1","created":"1984-01-23T22:00:00.000-10:00","updated":"2026-03-17T14:14:02.259-10:00","dg-path":"II. Teaching/Physics/Kinematics/Distance"}
---





> [!summary]
Distance is the total path travelled 
> 
**Key Equations:**
> 
Distance:
$|\Delta x| = |x_{2}-x_{1}|$

>[!info]+ Read Time
**⏱ 1 min**

# Definition 
Distance is the **total path travelled**. It's always a positive [[Scalar & Vectors\|scalar]] quantity. Distance is never zero unless you don't move over time. Mathematically, distance is described as the total accumulated motion from a to b:

$$
\begin{array}{c}
\text{Distance (1D)} = |\Delta x| = |x_{2}-x_{1}| \\ \\ 
\text{Or as a form of velocity:} \\

\Delta x = \int_{a}^b |v(t)|dt
\end{array}
$$

# Resources
<iframe width="560" height="315" src="https://www.youtube.com/embed/w_A_WHXWMU8?si=eBVQYfnKihr_n4qv" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>


---
<!-- Light Mode Newsletter Embed -->
<div class="mm-form-light">
  <iframe
    src="https://updates.cyberleadhub.com/widget/form/Y0kpQVpjJQuxEfX59m17"
    id="inline-Y0kpQVpjJQuxEfX59m17"
    title="Join Math & Matter Newsletter (Light)"
    data-height="900"
    scrolling="no"
    allowtransparency="true"
    loading="lazy"
    style="width:100%;height:350px;border:none;border-radius:10px;background:transparent;overflow:hidden"
  ></iframe>
</div>

<!-- Dark Mode Newsletter Embed -->
<div class="mm-form-dark">
  <iframe
    src="https://updates.cyberleadhub.com/widget/form/lbeDLm24VjuaFxhjccA1"
    id="inline-lbeDLm24VjuaFxhjccA1"
    title="Join Math & Matter Newsletter (Dark)"
    data-height="900"
    scrolling="no"
    allowtransparency="true"
    loading="lazy"
    style="width:100%;height:350px;border:none;border-radius:10px;background:transparent;overflow:hidden"
  ></iframe>
</div>

<!-- Provider script (only once) -->
<script src="https://updates.cyberleadhub.com/js/form_embed.js"></script>
