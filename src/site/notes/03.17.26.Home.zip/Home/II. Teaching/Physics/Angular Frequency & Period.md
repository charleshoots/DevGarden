---
{"dg-publish":true,"dg-path":"II. Teaching/Physics/Angular Frequency & Period","permalink":"/ii-teaching/physics/angular-frequency-and-period/","dgPassFrontmatter":true,"noteIcon":"1","created":"1984-01-23T22:00:00.000-10:00","updated":"2026-03-17T15:04:06.846-10:00"}
---



> [!summary]
The period is the time to complete one rotation.
Frequency is the rotations per second
> 
**Key Equations:**
> 
Period:
$T = \text{Time for one cycle}$
> 
Frequency:
$f =\frac{\text{Cycles}}{\text{second}}$
> 
Reciprocal:
$T = \frac{1}{f}$
$f=\frac{1}{T}$

>[!info]+ Read Time
**⏱ 1 min**

# Definition 
Angular frequency and period both describe how fast an object is rotating around a circle. Period ($T$) is the time to take to complete 1 full rotation (one oscillation or revolution). It is measured in seconds. Frequency ($f$) is the number of cycles per second, measured in Hz.

$$
\begin{align*}
\text{Period} &= \text{Time for one cycle} \\ 
&= \frac{1}{f} \\ \\ 
\text{Frequency} &=  \frac{\text{Cycles}}{\text{Second}} \\ 
&= \frac{1}{T}
\end{align*}
$$


---

> ✍️ This project’s been a labour of love.  
> If it helped, [give Math & Matter a star](https://github.com/rajeevphysics/Obsidian-MathMatter) and let me know what you'd like to see next.

---
