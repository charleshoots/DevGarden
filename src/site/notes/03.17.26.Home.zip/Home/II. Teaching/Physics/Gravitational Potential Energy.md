---
{"dg-publish":true,"tags":["teaching","physics","energywork"],"permalink":"/ii/","dgPassFrontmatter":true,"noteIcon":"1","created":"1984-01-23T22:00:00.000-10:00","updated":"2026-03-17T14:14:02.215-10:00","dg-path":"II. Teaching/Physics/Energy & Work/Gravitational Potential Energy"}
---





> [!summary]
Gravitational potential energy is the amount of work against gravity to move a mass from a reference point to a chosen point.
>
**Key equation:**
$\Delta U = mgy$

>[!info]+ Read Time
**⏱ 1 min**

# Definition 
Gravitational potential energy is the amount of [work](Work) you must do against gravity to move a mass from a chosen reference point to another point. 

If masses naturally want to remain at the reference point, the higher the mass it moves, the more potential energy it has and the more work that must be done.

## Derivation
> [!warning] Assumptions
To derive the gravitational potential energy, assume the following:
> - The [potential energy is related to work](Kinetic%20Potential%20Energy%20&%20Work-Energy%20Theorem) as $\Delta U = -W$
> - The total [work](Work) is from the ground to some height $y$ value
> - Assume the ground (0 position) has no potential energy
> - Let upwards be positive
> 
Use the image below as visual aid [^1]
![[ga_1.png\|300]]

$$
\begin{align*}{} 
\Delta U &= -W \\
&=-\int_{0}^{y} F_{g} dy \\
&= -\int_{0}^{y} -mg\cdot dy \\
&= mg \int_{0}^{y} dy \\
&= mgy
\end{align*} 
$$


[^1]: Taken from https://tikz.net/dynamics_gravity/ by Izaak Neutelings (Febuary 2022)


---
<!-- Light Mode Newsletter Embed -->
<div class="mm-form-light">
  <iframe
    src="https://updates.cyberleadhub.com/widget/form/Y0kpQVpjJQuxEfX59m17"
    id="inline-Y0kpQVpjJQuxEfX59m17"
    title="Join Math & Matter Newsletter (Light)"
    data-height="900"
    scrolling="no"
    allowtransparency="true"
    loading="lazy"
    style="width:100%;height:350px;border:none;border-radius:10px;background:transparent;overflow:hidden"
  ></iframe>
</div>

<!-- Dark Mode Newsletter Embed -->
<div class="mm-form-dark">
  <iframe
    src="https://updates.cyberleadhub.com/widget/form/lbeDLm24VjuaFxhjccA1"
    id="inline-lbeDLm24VjuaFxhjccA1"
    title="Join Math & Matter Newsletter (Dark)"
    data-height="900"
    scrolling="no"
    allowtransparency="true"
    loading="lazy"
    style="width:100%;height:350px;border:none;border-radius:10px;background:transparent;overflow:hidden"
  ></iframe>
</div>

<!-- Provider script (only once) -->
<script src="https://updates.cyberleadhub.com/js/form_embed.js"></script>
