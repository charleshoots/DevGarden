---
{"dg-publish":true,"dg-path":"II. Teaching/Physics/Newton Laws","permalink":"/ii-teaching/physics/newton-laws/","dgPassFrontmatter":true,"noteIcon":"1","created":"1984-01-23T22:00:00.000-10:00","updated":"2026-03-17T15:04:06.794-10:00"}
---


> [!summary]
Newton's laws are descriptions of forces best described in a perfect vacuum and in inertial frames of reference.

>[!info]+ Read Time
**⏱ 1 min**

# Definition 
Newton's laws are a set of experimentally proven results that describe classical forces. 

Newton's first law is "an object will continue in their motion unless a force acts on it." Which is true because in an [[Home/II. Teaching/Physics/Frames of Reference\|inertial frame of reference]], if an object is moving at some velocity in a vacuum space, it will continue with the velocity unless acted on by a force.

Newton's second law is "The amount of force on an object can be described as $F=ma$."
This is a mathematical statement to describe the force an object has in relation to its mass and acceleration.

> [!note] Derivation of Newton's Second Law through [[Home/II. Teaching/Physics/Linear Momentum\|linear momentum]]
> $$\begin{array}{c}
p = mv \\ 
\frac{dp}{dt} = m \frac{dv}{dt} \\ 
\underbrace{\frac{dp}{dt}}_{F} = ma \\  \\
F=ma
\end{array}
> $$
 
Newtons third law is  "If two objects interact they will exert the same amount of force on each other. " This is a statement that forces come in pairs that are exact opposite of one another ($F_{12} = -F_{21}$).


# Resources
<iframe width="560" height="315" src="https://www.youtube.com/embed/oduZsA0Tk58?si=cADVzoZ5IqlJpVob" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>


---

> ✍️ This project’s been a labour of love.  
> If it helped, [give Math & Matter a star](https://github.com/rajeevphysics/Obsidian-MathMatter) and let me know what you'd like to see next.

---
