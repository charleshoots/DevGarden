---
{"tags":["Topology"],"dg-publish":true,"dg-path":"II. Teaching/Mathematics/Compactly Generated","permalink":"/ii-teaching/mathematics/compactly-generated/","dgPassFrontmatter":true,"noteIcon":"1","created":"2026-02-08T18:42:15.000-10:00","updated":"2026-03-17T15:04:05.173-10:00"}
---


Subjects: [[charleshoots.net/II. Teaching/Mathematics/Topology\|Topology]]
Links: [[charleshoots.net/II. Teaching/Mathematics/Compactness-Type Properties\|Compactness-Type Properties]], [[charleshoots.net/II. Teaching/Mathematics/Compactness\|Compactness]]

**Def:** A toplogical space is said to be *compactly generated* if it has the following property: if $A$ is any subset of $X$ whose intersection with each compact subset $K\subseteq X$ is closed in $K$, then $A$ is closed in $X$. 

**Lemma:** First countable spaces and [[charleshoots.net/II. Teaching/Mathematics/Local Compactness\|locally compact]] spaces are compactly generated.