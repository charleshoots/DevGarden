---
{"dg-publish":true,"tags":["Geophysics","references/Terminology","References","teaching","terminology"],"dg-path":"II. Teaching/References/Terminology/Geophysics/' SKKPdf '","permalink":"/ii/","dgPassFrontmatter":true,"noteIcon":"1","created":"2026-03-16T18:10:07.931-10:00","updated":"2026-03-17T14:14:04.503-10:00"}
---





# Untitled Note

#references/IASPEI-Seismic-Phase-List #LEGACY/LEGACY-NOTES

SKKPdf

Tuesday, January 07, 2014

12:25 PM

SKKP bottoming in the inner core

Created with Microsoft OneNote 2016.



    Created: 2014-01-07
    Updated: 2014-01-07