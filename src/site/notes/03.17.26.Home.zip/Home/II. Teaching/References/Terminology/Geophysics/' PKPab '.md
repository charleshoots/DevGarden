---
{"dg-publish":true,"tags":["Geophysics","references/Terminology","References","teaching","terminology"],"dg-path":"II. Teaching/References/Terminology/Geophysics/' PKPab '","permalink":"/ii/","dgPassFrontmatter":true,"noteIcon":"1","created":"2026-03-16T18:10:07.925-10:00","updated":"2026-03-17T14:14:04.061-10:00"}
---






# Untitled Note

#references/IASPEI-Seismic-Phase-List #LEGACY/LEGACY-NOTES

PKPab

Tuesday, January 07, 2014

12:25 PM

(old:PKP2) P wave bottoming in the upper outer core; ab indicates the retrograde branch of the PKP caustic

Created with Microsoft OneNote 2016.



    Created: 2014-01-07
    Updated: 2014-01-07