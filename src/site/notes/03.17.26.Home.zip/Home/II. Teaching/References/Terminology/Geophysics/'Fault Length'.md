---
{"dg-publish":true,"tags":["Geophysics","references/Terminology","References","teaching","terminology"],"dg-path":"II. Teaching/References/Terminology/Geophysics/'Fault Length'","permalink":"/ii/","dgPassFrontmatter":true,"noteIcon":"1","created":"2026-03-16T18:10:07.947-10:00","updated":"2026-03-17T14:14:06.245-10:00"}
---





# Untitled Note
 #LEGACY/LEGACY-NOTES

Fault Length

Sunday, January 05, 2014

6:00 PM

fault length: (1) the total length of a fault or fault zone. (2) the rupture length along a fault or fault zone associated with a specific earthquake, representing either the observed surface rupture length or the rupture length at depth, usually determined from the aftershock distribution of the earthquake.

Created with Microsoft OneNote 2016.



    Created: 2014-01-05
    Updated: 2014-01-05