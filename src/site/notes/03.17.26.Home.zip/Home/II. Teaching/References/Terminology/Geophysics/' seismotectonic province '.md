---
{"dg-publish":true,"tags":["Geophysics","references/Terminology","References","teaching","terminology"],"dg-path":"II. Teaching/References/Terminology/Geophysics/' seismotectonic province '","permalink":"/ii/","dgPassFrontmatter":true,"noteIcon":"1","created":"2026-03-16T18:10:07.938-10:00","updated":"2026-03-17T14:14:05.277-10:00"}
---





# Untitled Note
 #LEGACY/LEGACY-NOTES

seismotectonic province

Sunday, January 05, 2014

6:01 PM

a region within which the active geologic and seismic processes are considered to be relatively uniform.

Created with Microsoft OneNote 2016.



    Created: 2014-01-05
    Updated: 2014-01-05