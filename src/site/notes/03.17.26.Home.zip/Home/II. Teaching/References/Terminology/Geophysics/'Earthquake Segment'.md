---
{"dg-publish":true,"tags":["Geophysics","references/Terminology","References","teaching","terminology"],"dg-path":"II. Teaching/References/Terminology/Geophysics/'Earthquake Segment'","permalink":"/ii/","dgPassFrontmatter":true,"noteIcon":"1","created":"2026-03-16T18:10:07.946-10:00","updated":"2026-03-17T14:14:06.231-10:00"}
---





# Untitled Note
 #LEGACY/LEGACY-NOTES

Earthquake Segment

Sunday, January 05, 2014

6:00 PM

earthquake segment: that part of a fault zone or fault zones that has ruptured during individual earthquakes.

Created with Microsoft OneNote 2016.



    Created: 2014-01-05
    Updated: 2014-01-05