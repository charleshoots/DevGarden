---
{"dg-publish":true,"tags":["Geophysics","references/Terminology","References","teaching","terminology"],"dg-path":"II. Teaching/References/Terminology/Geophysics/'Higher Modes (overtones)'","permalink":"/ii/","dgPassFrontmatter":true,"noteIcon":"1","created":"2026-03-16T18:10:07.953-10:00","updated":"2026-03-17T14:14:06.600-10:00"}
---





# Untitled Note
 #LEGACY/LEGACY-NOTES

Higher Modes (overtones)

Sunday, January 05, 2014

6:00 PM

higher-modes (overtones): secondary frequencies generated that have one or more nodes of zero motion (see also Fundamental mode).

Created with Microsoft OneNote 2016.



    Created: 2014-01-05
    Updated: 2014-01-05