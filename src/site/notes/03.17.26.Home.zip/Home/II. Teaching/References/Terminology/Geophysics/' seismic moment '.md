---
{"dg-publish":true,"tags":["Geophysics","references/Terminology","References","teaching","terminology"],"dg-path":"II. Teaching/References/Terminology/Geophysics/' seismic moment '","permalink":"/ii/","dgPassFrontmatter":true,"noteIcon":"1","created":"2026-03-16T18:10:07.937-10:00","updated":"2026-03-17T14:14:05.087-10:00"}
---






# Untitled Note
 #LEGACY/LEGACY-NOTES

seismic moment

Sunday, January 05, 2014

6:00 PM

a measure of earthquake size related to the leverage of the forces (couples) across the area of the fault slip. The rigidity of the rock times the the area of faulting times the amount of slip. Dimensions are dyne-cm (or Newton-meters).

Created with Microsoft OneNote 2016.



    Created: 2014-01-05
    Updated: 2014-01-05