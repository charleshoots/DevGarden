---
{"dg-publish":true,"tags":["Geophysics","references/Terminology","References","teaching","terminology"],"dg-path":"II. Teaching/References/Terminology/Geophysics/' Pz-P '","permalink":"/ii/","dgPassFrontmatter":true,"noteIcon":"1","created":"2026-03-16T18:10:07.928-10:00","updated":"2026-03-17T14:14:04.249-10:00"}
---






# Untitled Note

#references/IASPEI-Seismic-Phase-List #LEGACY/LEGACY-NOTES

Pz-P

Tuesday, January 07, 2014

12:25 PM

P reflection from inner side of discontinuity at depth z. For example, P660-P is a P reflection from below the 660 km discontinuity, which means it is precursory to PP.

Created with Microsoft OneNote 2016.



    Created: 2014-01-07
    Updated: 2014-01-07