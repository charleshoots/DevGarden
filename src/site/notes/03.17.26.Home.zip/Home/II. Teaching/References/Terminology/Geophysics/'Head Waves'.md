---
{"dg-publish":true,"tags":["Geophysics","Geophysics/seismology","teaching","references","terminology"],"dg-path":"II. Teaching/References/Terminology/Geophysics/'Head Waves'","permalink":"/ii/","dgPassFrontmatter":true,"noteIcon":"1","created":"2026-03-16T18:10:07.953-10:00","updated":"2026-03-17T14:14:06.511-10:00"}
---





# Untitled Note
 #LEGACY/LEGACY-NOTES

Head Waves

Sunday, January 05, 2014

6:00 PM

head waves: head waves are observed in a half-space that is in welded contact with another half-space with higher velocity when the seismic source is located in the lower velocity medium. The ray path of the head wave is along the interface. One example is Pn.

Created with Microsoft OneNote 2016.



    Created: 2014-01-05
    Updated: 2014-01-05