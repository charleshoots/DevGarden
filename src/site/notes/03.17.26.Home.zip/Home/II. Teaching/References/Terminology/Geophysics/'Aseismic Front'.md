---
{"dg-publish":true,"tags":["Geophysics","references/Terminology","References","teaching","terminology"],"dg-path":"II. Teaching/References/Terminology/Geophysics/'Aseismic Front'","permalink":"/ii/","dgPassFrontmatter":true,"noteIcon":"1","created":"2026-03-16T18:10:07.942-10:00","updated":"2026-03-17T14:14:05.750-10:00"}
---





# Untitled Note
 #LEGACY/LEGACY-NOTES

Aseismic Front

Sunday, January 05, 2014

5:59 PM

aseismic front: In a subduction zone, the boundary between the seismogenic foerearc basin and the aseismic volcanic arc.

Created with Microsoft OneNote 2016.



    Created: 2014-01-05
    Updated: 2014-01-05