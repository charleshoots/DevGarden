---
{"dg-publish":true,"tags":["Geophysics","references/Terminology","References","teaching","terminology"],"dg-path":"II. Teaching/References/Terminology/Geophysics/' wavelength '","permalink":"/ii/","dgPassFrontmatter":true,"noteIcon":"1","created":"2026-03-16T18:10:07.942-10:00","updated":"2026-03-17T14:14:05.696-10:00"}
---





# Untitled Note
 #LEGACY/LEGACY-NOTES

wavelength

Sunday, January 05, 2014

6:01 PM

the distance between two successive crest or troughs of a seismic signal.

Created with Microsoft OneNote 2016.



    Created: 2014-01-05
    Updated: 2014-01-05