---
{"dg-publish":true,"tags":["Geophysics","references/Terminology","References","teaching","terminology"],"dg-path":"II. Teaching/References/Terminology/Geophysics/' Response '","permalink":"/ii/","dgPassFrontmatter":true,"noteIcon":"1","created":"2026-03-16T18:10:07.929-10:00","updated":"2026-03-17T14:14:04.371-10:00"}
---





# Untitled Note
 #LEGACY/LEGACY-NOTES

Response

Sunday, January 05, 2014

6:00 PM

response: The motion in a system resulting from shaking under specified conditions.

Created with Microsoft OneNote 2016.



    Created: 2014-01-05
    Updated: 2014-01-05