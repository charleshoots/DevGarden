---
{"dg-publish":true,"tags":["Geophysics","references/Terminology","References","teaching","terminology"],"dg-path":"II. Teaching/References/Terminology/Geophysics/'Least-Squares Inverse'","permalink":"/ii/","dgPassFrontmatter":true,"noteIcon":"1","created":"2026-03-16T18:10:07.954-10:00","updated":"2026-03-17T14:14:06.714-10:00"}
---





# Untitled Note
 #LEGACY/LEGACY-NOTES

Least-Squares Inverse

Sunday, January 05, 2014

6:00 PM

least-squares inverse: a solution to matrix inversion problem where the squared error is minimized.

Created with Microsoft OneNote 2016.



    Created: 2014-01-05
    Updated: 2014-01-05